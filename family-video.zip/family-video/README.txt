Codespaces-এ চালানোর নিয়ম:
1) টার্মিনালে:  unzip family-video.zip && cd family-video
2) চালান:  bash setup.sh < /dev/null > setup.log 2>&1 &
3) অগ্রগতি দেখুন:  tail -c 400 setup.log | tr '\r' '\n' | tail -n 3
4) শেষে ভিডিও: out/story.mp4
