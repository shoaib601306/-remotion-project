import React from 'react';
import { interpolate } from 'remotion';
import { C, clamp } from './theme';
import { Stage } from './chrome';
import { Person, Mini, Bubble } from './figures';
import { TOTAL } from './data';
import * as K from './kit';
const { mouthOpen, useT, sp, breathe, blinkAt, RoomLiving, Megaphone } = K;
type SP = K.SP;
const O = K.O;
void Megaphone;

// ---- characters (same look in every scene) ----
const RAFI = { skin: '#9A6238', ear: '#8A5530', shirt: '#6E96BB', pants: '#2A3550', hair: '#15110e' };
const MOM = { skin: '#9A6238', ear: '#8A5530', shirt: '#B5543A', pants: '#6b3a3a', hair: '#1b140f', long: true };
const DAD = { skin: '#946037', ear: '#84552f', shirt: '#9DBBD6', pants: '#2b2f3f', hair: '#9a9a9a', glasses: true };
const KID = { skin: '#A86D40', ear: '#97603A', shirt: '#7aa97a', pants: '#3a4660', hair: '#1b140f' };
const k1 = (x: number) => Math.min(1, x);

// ---- icons ----
const Heart: React.FC<{ x: number; y: number; k?: number; c?: string }> = ({ x, y, k = 1, c = C.red }) => (
  <path transform={`translate(${x},${y}) scale(${k})`} d="M0 14 C-34 -12 -24 -38 0 -20 C24 -38 34 -12 0 14Z" fill={c} stroke={O} strokeWidth={3} strokeLinejoin="round" />
);
const Anger: React.FC<{ x: number; y: number; k?: number }> = ({ x, y, k = 1 }) => (
  <g transform={`translate(${x},${y}) scale(${k})`} stroke={C.red} strokeWidth={5} strokeLinecap="round" fill="none">
    <path d="M-14 -4 Q-4 -4 -4 -14 M14 -4 Q4 -4 4 -14 M-14 4 Q-4 4 -4 14 M14 4 Q4 4 4 14" />
  </g>
);
const Phone: React.FC<{ x: number; y: number; r?: number; k?: number }> = ({ x, y, r = -12, k = 1 }) => (
  <g transform={`translate(${x},${y}) rotate(${r}) scale(${k})`}>
    <rect width={32} height={54} rx={6} fill="#222" stroke={O} strokeWidth={2.5} />
    <rect x={3} y={5} width={26} height={44} rx={3} fill="#9fd4ff" />
    {[0, 1, 2].map((i) => <rect key={i} x={8 + i * 7} y={40 - (i + 1) * 8} width={5} height={(i + 1) * 8} fill={C.teal} />)}
  </g>
);
const Card: React.FC<{ x: number; y: number; w: number; h: number; k: number; children?: React.ReactNode }> = ({ x, y, w, h, k, children }) => (
  <g transform={`translate(${x},${y}) scale(${k1(k)})`} opacity={k1(k)}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={22} fill="#F6EFE8" stroke={O} strokeWidth={3} />
    {children}
  </g>
);
const Bulb: React.FC<{ x: number; y: number; k: number }> = ({ x, y, k }) => (
  <g transform={`translate(${x},${y}) scale(${k})`} opacity={k1(k)}>
    <circle r={24} fill="#FFD76A" stroke={O} strokeWidth={3} />
    <rect x={-10} y={22} width={20} height={14} rx={4} fill="#8c7a5c" stroke={O} strokeWidth={3} />
    {[-50, 0, 50].map((a) => <path key={a} d="M0 -34 V-48" stroke="#E8B84A" strokeWidth={4} strokeLinecap="round" transform={`rotate(${a})`} />)}
  </g>
);
const Coins: React.FC<{ x: number; y: number }> = ({ x, y }) => (
  <g transform={`translate(${x},${y})`}>
    {[0, 1, 2].map((i) => <ellipse key={i} cx={0} cy={18 - i * 12} rx={30} ry={11} fill="#F2C94C" stroke={O} strokeWidth={3} />)}
    <text y={-14} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={22} fill={C.ink}>৳</text>
  </g>
);

// ---- living room ----
const Sofa: React.FC = () => (
  <>
    <rect x={20} y={450} width={200} height={210} rx={34} fill="#96A5AB" stroke={O} strokeWidth={3} />
    <rect x={20} y={600} width={200} height={60} rx={20} fill="#869499" />
  </>
);
const Living: React.FC<{ f: number; sofa?: boolean; children?: React.ReactNode }> = ({ f, sofa, children }) => (
  <>
    <RoomLiving />
    {sofa && <Sofa />}
    <circle cx={470} cy={120} r={0} fill="none" opacity={f * 0} />
    {children}
  </>
);
const RafiSit: React.FC<{ f: number; t: number; sad?: boolean; phone?: boolean; mouth?: boolean }> = ({ f, t, sad, phone, mouth }) => (
  <>
    <Person x={112} y={520 + breathe(f)} s={0.82} {...RAFI} blink={blinkAt(f)} sad={sad} mouth={mouth ?? mouthOpen('rafi', t)} />
    {phone && <Phone x={200} y={392} />}
  </>
);

// ================= দৃশ্য =================
export const SA: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const h = k1(sp(lf(0.5)));
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <g transform="translate(270,400)">
        <path d="M-190 -20 L0 -170 L190 -20 Z" fill={C.red} stroke={O} strokeWidth={4} strokeLinejoin="round" />
        <rect x={-150} y={-20} width={300} height={200} fill="#F6EFE8" stroke={O} strokeWidth={4} />
        <rect x={-30} y={70} width={60} height={110} rx={8} fill="#8c6a4f" stroke={O} strokeWidth={3} />
        <rect x={-120} y={20} width={60} height={60} fill="#aebfc4" stroke={O} strokeWidth={3} />
        <rect x={60} y={20} width={60} height={60} fill="#aebfc4" stroke={O} strokeWidth={3} />
        <Heart x={0} y={-70} k={h * 1.4} />
      </g>
      {['#6E96BB', '#B5543A', '#9DBBD6', '#7aa97a'].map((c, i) => <Mini key={i} x={140 + i * 87} y={720} s={[1.5, 1.7, 1.8, 1.2][i]} color={c} bob={breathe(f + i * 9, 1.2)} />)}
    </Stage>
  );
};

export const SB: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const cl = k1(sp(lf(2.3)));
  return (
    <Stage dur={dur}>
      <Living f={f} sofa>
        <RafiSit f={f} t={t} phone />
        <Person x={430} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...MOM} blink={blinkAt(f + 30)} />
        <Person x={330} y={560 + breathe(f + 5)} s={0.6} pose="stand" flip {...KID} blink={blinkAt(f + 50)} />
        <g transform={`translate(170,260) scale(${cl})`} opacity={cl}>
          <rect x={-60} y={-40} width={130} height={80} rx={36} fill="#F6EFE8" stroke={O} strokeWidth={3} />
          <Phone x={-14} y={-26} r={0} k={0.9} />
        </g>
        {t > 5.3 && <Bubble x={430} y={238} text="…" w={54} delay={lf(5.3)} />}
      </Living>
    </Stage>
  );
};

const Trio: React.FC<{ f: number; t: number; momArm?: boolean; sad?: boolean; showKid?: number; angry?: boolean; rafiPhone?: boolean }> = ({ f, t, momArm, sad, showKid = 0, angry, rafiPhone = true }) => (
  <>
    <RafiSit f={f} t={t} sad={sad} phone={rafiPhone} />
    <Person x={420} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...MOM} blink={blinkAt(f + 30)} mouth={mouthOpen('mom', t)} arm={momArm ? 'raise' : 'rest'} hand={momArm ? [120 + Math.sin(f / 6) * 6, -150] : undefined} sad={angry} />
    {showKid > 0 && <Person x={330 + (1 - k1(showKid)) * 260} y={560 + breathe(f + 5)} s={0.6} pose="stand" flip {...KID} blink={blinkAt(f + 50)} mouth={mouthOpen('kid', t)} />}
  </>
);

export const SC: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  return <Stage dur={dur}><Living f={f} sofa><Trio f={f} t={t} momArm /></Living></Stage>;
};

export const SD: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <Living f={f} sofa>
        <Trio f={f} t={t} sad />
        {t > 17.0 && <Anger x={150} y={235 - Math.abs(Math.sin(f / 5)) * 4} k={k1(sp(lf(17.0))) * 1.4} />}
      </Living>
    </Stage>
  );
};

export const SE: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <Living f={f} sofa>
        <Trio f={f} t={t} sad showKid={sp(lf(20.3), { damping: 18, stiffness: 90, mass: 1 })} angry />
        {t > 20.6 && <Bubble x={300} y={330} text="?" w={54} delay={lf(20.6)} />}
      </Living>
    </Stage>
  );
};

export const SF: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const up = k1(sp(lf(22.95), { damping: 14, stiffness: 160, mass: 0.8 }));
  return (
    <Stage dur={dur}>
      <Living f={f}>
        <Person x={140} y={520 + breathe(f) - up * 6} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} sad arm="raise" hand={[130 + Math.sin(f / 4) * 6, -150]} mouth={mouthOpen('rafi', t)} />
        <Person x={330} y={560 + breathe(f + 5)} s={0.6} pose="stand" flip {...KID} sad />
        <Person x={450} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...MOM} sad />
        <Anger x={160} y={225} k={up * 1.5} />
      </Living>
    </Stage>
  );
};

const Door: React.FC = () => (
  <>
    <rect x={410} y={200} width={130} height={410} fill="#8c6a4f" stroke={O} strokeWidth={4} />
    <rect x={425} y={215} width={100} height={380} fill="#a98763" />
    <circle cx={440} cy={420} r={6} fill="#E8B84A" />
  </>
);
const Briefcase: React.FC<{ x: number; y: number }> = ({ x, y }) => (
  <g transform={`translate(${x},${y})`}>
    <path d="M-12 0 V-10 H12 V0" fill="none" stroke={O} strokeWidth={4} />
    <rect x={-30} y={0} width={60} height={42} rx={6} fill="#5a3d28" stroke={O} strokeWidth={3} />
  </g>
);

export const SG: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const dx = 560 - k1(sp(lf(25.8), { damping: 18, stiffness: 80, mass: 1 })) * 130;
  return (
    <Stage dur={dur}>
      <Living f={f}>
        <Door />
        <Person x={90} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} sad />
        <Person x={190} y={560 + breathe(f + 5)} s={0.6} pose="stand" {...KID} sad />
        <Person x={280} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...MOM} sad />
        <Person x={dx} y={520 + breathe(f + 9)} s={0.8} pose="stand" flip {...DAD} blink={blinkAt(f + 20)} sad={t > 28.9} />
        <Briefcase x={dx - 70} y={430} />
        {t < 28.9 && [90, 280].map((x, i) => <Anger key={i} x={x + 30} y={236 + Math.sin(f / 4 + i) * 4} k={1.2} />)}
        {t > 28.9 && <Bubble x={dx - 40} y={238} text="?" w={54} delay={lf(28.97)} />}
      </Living>
    </Stage>
  );
};

const Gather: React.FC<{ f: number; t: number; momArm?: boolean; dadArm?: boolean; heart?: number }> = ({ f, t, momArm, dadArm, heart = 0 }) => (
  <>
    <Person x={80} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} sad />
    <Person x={200} y={560 + breathe(f + 5)} s={0.6} pose="stand" {...KID} />
    <Person x={300} y={520 + breathe(f + 15)} s={0.8} pose="stand" {...MOM} blink={blinkAt(f + 30)} mouth={mouthOpen('mom', t)} arm={momArm ? 'raise' : 'rest'} hand={momArm ? [120 + Math.sin(f / 6) * 6, -150] : undefined} sad={!heart} />
    <Person x={450} y={520 + breathe(f + 9)} s={0.8} pose="stand" flip {...DAD} blink={blinkAt(f + 20)} mouth={mouthOpen('dad', t)} arm={dadArm ? 'raise' : 'rest'} hand={dadArm ? [120 + Math.sin(f / 7) * 5, -150] : undefined} />
    {heart > 0 && <Heart x={330} y={230 - Math.sin(f / 8) * 5} k={k1(heart) * 1.9} />}
  </>
);

export const SH: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  return <Stage dur={dur}><Living f={f}><Gather f={f} t={t} dadArm /></Living></Stage>;
};

export const SI: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  return <Stage dur={dur}><Living f={f}><Gather f={f} t={t} momArm /></Living></Stage>;
};

export const SJ: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const a = sp(lf(43.8)), b = sp(lf(45.8)), x = sp(lf(46.9), { damping: 9, stiffness: 220, mass: 0.7 });
  return (
    <Stage dur={dur}>
      <Living f={f}>
        <Person x={120} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} sad />
        <Person x={420} y={520 + breathe(f + 9)} s={0.8} pose="stand" flip {...DAD} blink={blinkAt(f + 20)} mouth={mouthOpen('dad', t)} arm="raise" hand={[120 + Math.sin(f / 7) * 5, -150]} />
        {t > 43.7 && t < 48.3 && (
          <Card x={270} y={210} w={330} h={130} k={a}>
            <Coins x={-90} y={0} />
            <path d="M-45 -4 L-30 12 L-5 -18" stroke={C.teal} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" transform="translate(-4,0)" />
            <Heart x={95} y={0} k={k1(b) * 1.6} />
            <g transform={`translate(95,0) scale(${x})`} opacity={k1(x)}>
              <circle r={36} fill="none" stroke={C.red} strokeWidth={8} />
              <path d="M-22 -22 L22 22" stroke={C.red} strokeWidth={8} strokeLinecap="round" />
            </g>
          </Card>
        )}
      </Living>
    </Stage>
  );
};

export const SK: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <Living f={f}>
        <Gather f={f} t={t} dadArm heart={sp(lf(52.4))} />
      </Living>
    </Stage>
  );
};

export const SL: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <Living f={f} sofa>
        <RafiSit f={f} t={t} sad mouth={false} />
        <rect x={250} y={540} width={160} height={14} rx={5} fill="#6B4A32" stroke={O} strokeWidth={3} />
        <rect x={320} y={554} width={20} height={110} fill="#5a3d28" />
        <Phone x={300} y={500} r={80} k={0.9} />
        <Bulb x={150} y={235} k={sp(lf(57.0))} />
      </Living>
    </Stage>
  );
};

export const SM: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  return (
    <Stage dur={dur}>
      <Living f={f}>
        <Person x={150} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} sad mouth={mouthOpen('rafi', t)} />
        <Person x={400} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...MOM} blink={blinkAt(f + 30)} smile={t > 62} />
      </Living>
    </Stage>
  );
};

export const SN: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const close = k1(sp(lf(65.7), { damping: 18, stiffness: 80, mass: 1 }));
  return (
    <Stage dur={dur}>
      <Living f={f}>
        <Person x={60} y={560 + breathe(f)} s={0.6} pose="stand" {...KID} smile />
        <Person x={150 + close * 70} y={520 + breathe(f + 3)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} smile />
        <Person x={400 - close * 60} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...MOM} smile mouth={mouthOpen('mom', t)} />
        <Person x={470} y={520 + breathe(f + 9)} s={0.8} pose="stand" flip {...DAD} smile />
        {[0, 1, 2].map((i) => <Heart key={i} x={250 + i * 40} y={300 - ((f * 1.2 + i * 30) % 90)} k={0.9 * close} />)}
      </Living>
    </Stage>
  );
};

// ================= শিক্ষা =================
export const SO: React.FC<SP> = ({ t0, dur }) => {
  const { lf } = useT(t0);
  const r = k1(sp(lf(72.4))), c = [75.3, 76.4, 77.7].map((s) => k1(sp(lf(s))));
  const names = ['ভালোবাসা', 'সম্মান', 'সহযোগিতা'];
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <g transform={`translate(0,${(1 - r) * -40})`} opacity={r}>
        <path d="M50 330 L270 160 L490 330 Z" fill={C.red} stroke={O} strokeWidth={4} strokeLinejoin="round" />
        <rect x={40} y={330} width={460} height={20} rx={6} fill="#6B4A32" />
      </g>
      {names.map((n, i) => (
        <g key={n} transform={`translate(${80 + i * 140},${350 + (1 - c[i]) * -40})`} opacity={c[i]}>
          <rect width={100} height={300} rx={10} fill="#F6EFE8" stroke={O} strokeWidth={3} />
          <Heart x={50} y={60} k={0.9} c={[C.red, C.teal, '#D9A93A'][i]} />
          <text x={50} y={190} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={n.length > 7 ? 19 : 24} fill={C.ink}>{n}</text>
        </g>
      ))}
      <rect x={40} y={650} width={460} height={20} rx={6} fill="#6B4A32" opacity={r} />
    </Stage>
  );
};

export const SP2: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const w = k1(sp(lf(79.6))), back = interpolate(t, [80.6, 82.0], [0, 1], clamp);
  const fr = k1(sp(lf(83.0))), fade = interpolate(t, [86.0, 87.2], [1, 0.12], clamp);
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      {t < 83.0 && (
        <g transform={`translate(270,300) scale(${w})`} opacity={w}>
          <rect x={-70} y={-45} width={140} height={90} rx={14} fill="#8c5a3a" stroke={O} strokeWidth={4} />
          <rect x={-70} y={-45} width={140} height={34} rx={14} fill="#a56f49" stroke={O} strokeWidth={4} />
          <circle cx={0} cy={5} r={10} fill="#E8B84A" stroke={O} strokeWidth={2.5} />
          <g transform={`translate(${-150 + back * 150},${back < 1 ? -80 + back * 80 : 0})`} opacity={0.4 + 0.6 * back} />
          <path d="M-120 120 Q0 190 120 120 M95 100 L122 120 L96 140" fill="none" stroke={C.teal} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round" opacity={back} />
        </g>
      )}
      {t >= 83.0 && (
        <g transform={`translate(270,420) scale(${fr})`} opacity={fr * fade}>
          <rect x={-190} y={-170} width={380} height={340} rx={14} fill="#8c5a3a" stroke={O} strokeWidth={5} />
          <rect x={-165} y={-145} width={330} height={290} fill="#F6EFE8" />
          {['#6E96BB', '#B5543A', '#9DBBD6', '#7aa97a'].map((c, i) => <Mini key={i} x={-110 + i * 75} y={90} s={[1.4, 1.5, 1.6, 1.1][i]} color={c} />)}
          <Heart x={0} y={-90} k={1.6} />
        </g>
      )}
      {t >= 83.0 && (
        <g transform="translate(270,790)" opacity={0.5 + 0.5 * fade}>
          <circle r={54} fill="#F6EFE8" stroke={O} strokeWidth={4} />
          <path d={`M0 0 V-34`} stroke={O} strokeWidth={5} strokeLinecap="round" />
          <path d="M0 0 L22 10" stroke={O} strokeWidth={5} strokeLinecap="round" transform={`rotate(${(f * 3) % 360})`} />
        </g>
      )}
    </Stage>
  );
};

export const SQ: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <Living f={f}>
        <Person x={70} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} smile />
        <Person x={160} y={560 + breathe(f + 5)} s={0.6} pose="stand" {...KID} smile />
        <Person x={280} y={520 + breathe(f + 15)} s={0.8} pose="stand" {...MOM} smile />
        <Person x={420} y={520 + breathe(f + 9)} s={0.8} pose="stand" flip {...DAD} smile />
        {[0, 1, 2, 3].map((i) => <Heart key={i} x={120 + i * 100} y={300 - ((f * 1.1 + i * 25) % 110)} k={0.8 * k1(sp(lf(87.8 + i * 0.3)))} />)}
      </Living>
    </Stage>
  );
};

export const SR: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const h = k1(sp(lf(93.0)));
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <g transform="translate(270,430)">
        {Array.from({ length: 12 }).map((_, i) => <path key={i} d="M0 -250 L16 -200 H-16 Z" fill="#FFE08A" opacity={0.3} transform={`rotate(${i * 30 + f * 0.2})`} />)}
        <path d="M-200 -10 L0 -180 L200 -10 Z" fill={C.red} stroke={O} strokeWidth={4} strokeLinejoin="round" />
        <rect x={-160} y={-10} width={320} height={220} fill="#F6EFE8" stroke={O} strokeWidth={4} />
        <Heart x={0} y={-70} k={h * 1.5} />
        {['#6E96BB', '#B5543A', '#9DBBD6', '#7aa97a'].map((c, i) => <Mini key={i} x={-105 + i * 70} y={200} s={[1.4, 1.6, 1.7, 1.1][i]} color={c} bob={breathe(f + i * 9, 1.2)} />)}
      </g>
    </Stage>
  );
};

// List the scenes in time order. s/e are seconds on the final timeline; cuts sit inside voice pauses.
export const SCENES = [
  { s: 0.0, e: 1.7, C: SA }, { s: 1.7, e: 8.0, C: SB }, { s: 8.0, e: 16.55, C: SC },
  { s: 16.55, e: 20.2, C: SD }, { s: 20.2, e: 22.9, C: SE }, { s: 22.9, e: 25.5, C: SF },
  { s: 25.5, e: 32.4, C: SG }, { s: 32.4, e: 36.4, C: SH }, { s: 36.4, e: 40.1, C: SI },
  { s: 40.1, e: 48.2, C: SJ }, { s: 48.2, e: 56.0, C: SK }, { s: 56.0, e: 59.6, C: SL },
  { s: 59.6, e: 65.5, C: SM }, { s: 65.5, e: 72.0, C: SN }, { s: 72.0, e: 79.2, C: SO },
  { s: 79.2, e: 87.4, C: SP2 }, { s: 87.4, e: 92.2, C: SQ }, { s: 92.2, e: TOTAL, C: SR },
];
