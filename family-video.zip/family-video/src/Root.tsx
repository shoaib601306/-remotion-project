import React from 'react';
import {Composition} from 'remotion';
import {FamilyVideo} from './Video';

// Audio = 95.95s  ->  96s * 30fps = 2880 frames
export const Root: React.FC = () => {
  return (
    <Composition
      id="Family"
      component={FamilyVideo}
      durationInFrames={2880}
      fps={30}
      width={1920}
      height={1080}
    />
  );
};
