import React from 'react';
import {fontFamily} from './fonts';

export type Mood = 'neutral' | 'angry' | 'sad' | 'happy';
export type HairStyle = 'short' | 'bun' | 'pony' | 'long';

type Props = {
  x: number;
  floorY: number;
  scale: number;
  skin: string;
  hair: string;
  shirt: string;
  pants: string;
  hairStyle: HairStyle;
  glasses?: boolean;
  mood: Mood;
  speaking: boolean;
  frame: number;
  sit?: boolean;
  phone?: boolean;
  /** arm angle in degrees: 0 = hanging down, 90 = straight out, 180 = straight up, negative = across body */
  armL: number;
  armR: number;
  walking?: boolean;
  label?: string;
  seed?: number;
};

const ARM_LEN = 125;

export const Person: React.FC<Props> = ({
  x,
  floorY,
  scale,
  skin,
  hair,
  shirt,
  pants,
  hairStyle,
  glasses,
  mood,
  speaking,
  frame,
  sit,
  phone,
  armL,
  armR,
  walking,
  label,
  seed = 0,
}) => {
  const bob = walking
    ? -Math.abs(Math.sin(frame * 0.45)) * 12
    : Math.sin((frame + seed * 20) * 0.08) * 2.5;
  const swing = walking ? Math.sin(frame * 0.45) * 18 : 0;
  const up = sit ? 70 : 0;
  const blink = (frame + seed * 37) % 130 < 5;
  const mouthOpen = speaking ? 3 + 9 * Math.abs(Math.sin(frame * 0.7 + seed)) : 0;

  const arm = (side: -1 | 1, a: number) => {
    const sx = side * 62;
    const sy = -280 + up;
    const rad = (a * Math.PI) / 180;
    const ex = sx + side * Math.sin(rad) * ARM_LEN;
    const ey = sy + Math.cos(rad) * ARM_LEN;
    return (
      <g key={side}>
        <line x1={sx} y1={sy} x2={ex} y2={ey} stroke={shirt} strokeWidth={30} strokeLinecap="round" />
        <circle cx={ex} cy={ey} r={16} fill={skin} />
      </g>
    );
  };

  const brows = {
    neutral: [-30, -26, -9, -26, 9, -26, 30, -26],
    angry: [-31, -34, -8, -21, 8, -21, 31, -34],
    sad: [-31, -22, -8, -32, 8, -32, 31, -22],
    happy: [-30, -28, -9, -32, 9, -32, 30, -28],
  }[mood];

  const mouthPath = {
    neutral: 'M-14 26 L14 26',
    angry: 'M-16 32 Q0 20 16 32',
    sad: 'M-16 32 Q0 18 16 32',
    happy: 'M-20 20 Q0 46 20 20 Z',
  }[mood];

  return (
    <g transform={`translate(${x} ${floorY + bob}) scale(${scale})`}>
      {/* legs */}
      {!sit &&
        ([-1, 1] as const).map((s) => (
          <g key={s} transform={`rotate(${s * swing} ${s * 26} -170)`}>
            <rect x={s * 26 - 17} y={-176} width={34} height={176} rx={14} fill={pants} />
            <ellipse cx={s * 26 + s * 4} cy={0} rx={26} ry={11} fill="#222" />
          </g>
        ))}

      {/* torso */}
      <rect x={-56} y={-302 + up} width={112} height={134} rx={32} fill={shirt} />

      {/* arms */}
      {arm(-1, armL)}
      {arm(1, armR)}

      {/* phone held in front of chest */}
      {phone && (
        <g transform={`translate(0 ${-148 + up})`}>
          <rect x={-20} y={-34} width={40} height={68} rx={8} fill="#111" />
          <rect x={-16} y={-29} width={32} height={58} rx={5} fill="#7fd6ff" opacity={0.75 + 0.25 * Math.sin(frame * 0.2)} />
        </g>
      )}

      {/* head */}
      <g transform={`translate(0 ${-345 + up})`}>
        {hairStyle === 'long' && <ellipse cx={0} cy={20} rx={64} ry={80} fill={hair} />}
        <circle cx={-50} cy={4} r={9} fill={skin} />
        <circle cx={50} cy={4} r={9} fill={skin} />
        <circle cx={0} cy={0} r={50} fill={skin} />

        {/* hair cap */}
        <path
          d="M-55 -4 Q-58 -64 0 -64 Q58 -64 55 -4 Q42 -32 0 -36 Q-42 -32 -55 -4 Z"
          fill={hair}
        />
        {hairStyle === 'bun' && <circle cx={0} cy={-70} r={22} fill={hair} />}
        {hairStyle === 'pony' && (
          <ellipse cx={58} cy={20} rx={15} ry={40} fill={hair} transform="rotate(-18 58 20)" />
        )}

        {/* eyes */}
        {blink ? (
          <>
            <line x1={-26} y1={-5} x2={-12} y2={-5} stroke="#222" strokeWidth={4} strokeLinecap="round" />
            <line x1={12} y1={-5} x2={26} y2={-5} stroke="#222" strokeWidth={4} strokeLinecap="round" />
          </>
        ) : (
          <>
            <circle cx={-19} cy={-5} r={6.5} fill="#222" />
            <circle cx={19} cy={-5} r={6.5} fill="#222" />
          </>
        )}

        {/* brows */}
        <line x1={brows[0]} y1={brows[1]} x2={brows[2]} y2={brows[3]} stroke="#2a1a10" strokeWidth={5} strokeLinecap="round" />
        <line x1={brows[4]} y1={brows[5]} x2={brows[6]} y2={brows[7]} stroke="#2a1a10" strokeWidth={5} strokeLinecap="round" />

        {glasses && (
          <g fill="none" stroke="#333" strokeWidth={3.5}>
            <circle cx={-19} cy={-5} r={15} />
            <circle cx={19} cy={-5} r={15} />
            <line x1={-4} y1={-5} x2={4} y2={-5} />
          </g>
        )}

        {mood === 'happy' && (
          <>
            <circle cx={-32} cy={14} r={9} fill="#ff8a8a" opacity={0.45} />
            <circle cx={32} cy={14} r={9} fill="#ff8a8a" opacity={0.45} />
          </>
        )}

        {/* mouth */}
        {speaking ? (
          <ellipse cx={0} cy={26} rx={13} ry={mouthOpen} fill="#7a1f1f" />
        ) : (
          <path
            d={mouthPath}
            stroke="#7a1f1f"
            strokeWidth={5}
            strokeLinecap="round"
            strokeLinejoin="round"
            fill={mood === 'happy' ? '#fff' : 'none'}
          />
        )}

        {/* name tag above the speaker */}
        {speaking && label && (
          <g transform="translate(0 -112)">
            <rect x={-72} y={-27} width={144} height={54} rx={27} fill="#1d2433" opacity={0.88} />
            <text
              x={0}
              y={11}
              textAnchor="middle"
              fontSize={32}
              fontWeight={600}
              fill="#fff"
              style={{fontFamily}}
            >
              {label}
            </text>
          </g>
        )}
      </g>
    </g>
  );
};
