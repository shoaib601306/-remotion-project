import React from 'react';
import {AbsoluteFill, Audio, interpolate, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {Person, Mood} from './Person';
import {subs} from './subs';
import {fontFamily} from './fonts';

/* ---------- helpers ---------- */

const smooth = (x: number) => x * x * (3 - 2 * x);

/** piecewise value with smooth easing between [time, value] keyframes */
const kf = (t: number, pts: [number, number][]): number => {
  if (t <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    if (t <= pts[i][0]) {
      const [t0, v0] = pts[i - 1];
      const [t1, v1] = pts[i];
      return v0 + (v1 - v0) * smooth((t - t0) / (t1 - t0));
    }
  }
  return pts[pts.length - 1][1];
};

const moodAt = (t: number, list: [number, Mood][]): Mood => {
  let m = list[0][1];
  for (const [s, v] of list) if (t >= s) m = v;
  return m;
};

type Who = 'narr' | 'mom' | 'rafi' | 'sis' | 'dad';

/** who is speaking, in seconds (matched to the SRT / voiceover) */
const speakers: [number, number, Who][] = [
  [0.1, 8.4, 'narr'],
  [8.4, 10.6, 'narr'],
  [10.6, 16.0, 'mom'],
  [16.0, 20.4, 'rafi'],
  [20.4, 22.8, 'sis'],
  [23.0, 25.6, 'rafi'],
  [25.6, 32.7, 'narr'],
  [32.7, 36.6, 'dad'],
  [36.6, 40.4, 'mom'],
  [40.4, 56.4, 'dad'],
  [56.4, 58.8, 'narr'],
  [58.8, 64.6, 'rafi'],
  [64.6, 72.2, 'mom'],
  [72.2, 84.5, 'dad'],
  [84.5, 95.9, 'narr'],
];

const speakerAt = (t: number): Who | null => {
  for (const [a, b, w] of speakers) if (t >= a && t < b) return w;
  return null;
};

/* ---------- background ---------- */

const FLOOR_Y = 830;
const SOFA_X = 1400;

const Room: React.FC<{frame: number}> = ({frame}) => (
  <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
    <defs>
      <linearGradient id="wall" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#f6dfc0" />
        <stop offset="100%" stopColor="#efc99a" />
      </linearGradient>
      <linearGradient id="floor" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stopColor="#a9714a" />
        <stop offset="100%" stopColor="#7d4f31" />
      </linearGradient>
    </defs>
    <rect x={0} y={0} width={1920} height={720} fill="url(#wall)" />
    <rect x={0} y={720} width={1920} height={360} fill="url(#floor)" />
    <rect x={0} y={712} width={1920} height={14} fill="#d9b48a" />

    {/* window */}
    <rect x={740} y={110} width={330} height={320} rx={10} fill="#bfe6ff" stroke="#fff" strokeWidth={14} />
    <line x1={905} y1={110} x2={905} y2={430} stroke="#fff" strokeWidth={10} />
    <line x1={740} y1={270} x2={1070} y2={270} stroke="#fff" strokeWidth={10} />
    <rect x={700} y={95} width={50} height={350} fill="#c9604a" opacity={0.9} />
    <rect x={1060} y={95} width={50} height={350} fill="#c9604a" opacity={0.9} />

    {/* family photos */}
    <rect x={200} y={170} width={170} height={130} fill="#fff" stroke="#8a5a36" strokeWidth={10} />
    <circle cx={250} cy={225} r={18} fill="#e7b58a" />
    <circle cx={285} cy={225} r={18} fill="#d89a70" />
    <circle cx={320} cy={232} r={14} fill="#e7b58a" />
    <rect x={410} y={200} width={110} height={90} fill="#fff" stroke="#8a5a36" strokeWidth={8} />
    <path d="M420 280 L450 235 L478 262 L496 240 L512 280 Z" fill="#7fb77e" />

    {/* clock */}
    <circle cx={1560} cy={210} r={62} fill="#fff" stroke="#6b4a2e" strokeWidth={9} />
    <line x1={1560} y1={210} x2={1560} y2={168} stroke="#333" strokeWidth={5} strokeLinecap="round" />
    <line
      x1={1560}
      y1={210}
      x2={1560 + 34 * Math.sin(frame * 0.02)}
      y2={210 - 34 * Math.cos(frame * 0.02)}
      stroke="#333"
      strokeWidth={4}
      strokeLinecap="round"
    />

    {/* plant */}
    <rect x={95} y={690} width={80} height={110} rx={10} fill="#b0623b" />
    <ellipse cx={135} cy={640} rx={22} ry={70} fill="#4c9a53" transform="rotate(-22 135 640)" />
    <ellipse cx={135} cy={630} rx={22} ry={80} fill="#5db664" />
    <ellipse cx={135} cy={640} rx={22} ry={70} fill="#4c9a53" transform="rotate(22 135 640)" />

    {/* rug */}
    <ellipse cx={960} cy={900} rx={720} ry={110} fill="#c6584a" opacity={0.65} />
    <ellipse cx={960} cy={900} rx={620} ry={85} fill="none" stroke="#f1d6a5" strokeWidth={6} opacity={0.7} />
  </svg>
);

const SofaBack: React.FC = () => (
  <g>
    <rect x={SOFA_X - 250} y={FLOOR_Y - 340} width={500} height={250} rx={46} fill="#4a6fa5" />
  </g>
);

const SofaFront: React.FC = () => (
  <g>
    <rect x={SOFA_X - 250} y={FLOOR_Y - 95} width={500} height={110} rx={26} fill="#5a82bd" />
    <rect x={SOFA_X - 290} y={FLOOR_Y - 190} width={64} height={205} rx={28} fill="#3f6296" />
    <rect x={SOFA_X + 226} y={FLOOR_Y - 190} width={64} height={205} rx={28} fill="#3f6296" />
    <rect x={SOFA_X - 230} y={FLOOR_Y + 14} width={30} height={20} fill="#2c2c2c" />
    <rect x={SOFA_X + 200} y={FLOOR_Y + 14} width={30} height={20} fill="#2c2c2c" />
  </g>
);

/* ---------- hearts ---------- */

const Hearts: React.FC<{t: number}> = ({t}) => {
  if (t < 66) return null;
  return (
    <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
      {Array.from({length: 18}).map((_, i) => {
        const start = 66 + i * 0.8;
        if (t < start) return null;
        const speed = 90 + ((i * 37) % 70);
        const y = 1010 - (((t - start) * speed) % 1100);
        const hx = 80 + ((i * 211) % 1760) + Math.sin((t - start) * 2 + i) * 25;
        const s = 0.35 + ((i * 13) % 5) * 0.08;
        const fade = interpolate(t, [start, start + 1], [0, 1], {extrapolateRight: 'clamp'});
        return (
          <path
            key={i}
            d="M0 0 C-30 -35 -70 0 0 60 C70 0 30 -35 0 0Z"
            transform={`translate(${hx} ${y}) scale(${s})`}
            fill={i % 2 ? '#ff5d7a' : '#ff8fa3'}
            opacity={0.8 * fade}
          />
        );
      })}
    </svg>
  );
};

/* ---------- main ---------- */

export const FamilyVideo: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const tPrev = (frame - 1) / fps;

  const speaker = speakerAt(t);

  // --- positions ---
  const momX = (tt: number) => kf(tt, [[64, 620], [66, 640]]);
  const rafiX = (tt: number) => kf(tt, [[59.2, SOFA_X], [63.5, 760]]);
  const dadX = (tt: number) =>
    kf(tt, [[28, -160], [32, 1000], [40.4, 1000], [43, 1080], [64, 1080], [66, 960]]);
  const sisX = (tt: number) => kf(tt, [[66, 900], [69, 1090]]);

  const moving = (fn: (x: number) => number) => Math.abs(fn(t) - fn(tPrev)) > 0.6;

  // --- states ---
  const rafiSit = t < 59.2;
  const rafiPhone = t < 44;
  const hugging = t >= 63.5 && t < 72;
  const scolding = t > 10.6 && t < 18;

  const momArmR = hugging
    ? 125
    : scolding
    ? 95 + 12 * Math.sin(frame * 0.4)
    : speaker === 'mom'
    ? 40 + 15 * Math.sin(frame * 0.3)
    : 10;

  const dadArmR =
    speaker === 'dad' ? 70 + 18 * Math.sin(frame * 0.25) : 10;

  const rafiArms: [number, number] = hugging
    ? [125, 125]
    : rafiPhone
    ? [-50, -50]
    : t < 56.4
    ? [-60, -60] // arms crossed
    : [10, 10];

  const rafi = (
    <Person
      x={rafiX(t)}
      floorY={FLOOR_Y}
      scale={0.92}
      skin="#e2b48c"
      hair="#1c1410"
      shirt="#2e8b6e"
      pants="#2f3b57"
      hairStyle="short"
      mood={moodAt(t, [[0, 'neutral'], [13.7, 'angry'], [46, 'sad'], [66, 'happy']])}
      speaking={speaker === 'rafi'}
      frame={frame}
      sit={rafiSit}
      phone={rafiPhone}
      armL={rafiArms[0]}
      armR={rafiArms[1]}
      walking={moving(rafiX)}
      label="রাফি"
      seed={1}
    />
  );

  // slow push-in
  const zoom = interpolate(t, [0, 96], [1, 1.06]);

  // tint: tense/dim in the argument, bright & warm at the end
  const dim = interpolate(t, [8, 12, 46, 56, 66], [0, 0.22, 0.22, 0.06, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const warm = interpolate(t, [64, 70], [0, 0.18], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  // subtitle
  const cue = subs.find((c) => t >= c.start && t < c.end);
  const cueOpacity = cue
    ? interpolate(t, [cue.start, cue.start + 0.15], [0, 1], {extrapolateRight: 'clamp'})
    : 0;

  const titleOpacity = interpolate(t, [0, 0.3, 1.6, 2.2], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  const endOpacity = interpolate(t, [88, 90], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  return (
    <AbsoluteFill style={{backgroundColor: '#000', fontFamily}}>
      <Audio src={staticFile('voice.mp3')} />

      <AbsoluteFill style={{transform: `scale(${zoom})`, transformOrigin: '50% 60%'}}>
        <Room frame={frame} />

        <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
          <SofaBack />
          {rafiSit && rafi}
          <SofaFront />
          {!rafiSit && rafi}

          <Person
            x={momX(t)}
            floorY={FLOOR_Y}
            scale={0.98}
            skin="#e8bf9a"
            hair="#2a1b17"
            shirt="#c2415d"
            pants="#5b4a6b"
            hairStyle="bun"
            mood={moodAt(t, [[0, 'neutral'], [10.6, 'angry'], [40.4, 'sad'], [64, 'happy']])}
            speaking={speaker === 'mom'}
            frame={frame}
            armL={hugging ? 125 : 10}
            armR={momArmR}
            walking={moving(momX)}
            label="মা"
            seed={2}
          />

          <Person
            x={sisX(t)}
            floorY={FLOOR_Y}
            scale={0.76}
            skin="#e8bf9a"
            hair="#1c1410"
            shirt="#f2a93b"
            pants="#3f6a8f"
            hairStyle="pony"
            mood={moodAt(t, [[0, 'neutral'], [19, 'sad'], [66, 'happy']])}
            speaking={speaker === 'sis'}
            frame={frame}
            armL={10}
            armR={speaker === 'sis' ? 60 + 15 * Math.sin(frame * 0.3) : 10}
            walking={moving(sisX)}
            label="বোন"
            seed={3}
          />

          {t >= 28 && (
            <Person
              x={dadX(t)}
              floorY={FLOOR_Y}
              scale={1.05}
              skin="#d9a982"
              hair="#3a3a3f"
              shirt="#4a5a7a"
              pants="#2a2a32"
              hairStyle="short"
              glasses
              mood={moodAt(t, [[0, 'neutral'], [29, 'sad'], [56.4, 'neutral'], [66, 'happy']])}
              speaking={speaker === 'dad'}
              frame={frame}
              armL={10}
              armR={dadArmR}
              walking={moving(dadX)}
              label="বাবা"
              seed={4}
            />
          )}
        </svg>

        <Hearts t={t} />
      </AbsoluteFill>

      {/* mood tint */}
      <AbsoluteFill style={{background: `rgba(20,30,70,${dim})`, pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: `rgba(255,190,90,${warm})`, pointerEvents: 'none'}} />

      {/* title */}
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center', opacity: titleOpacity}}>
        <div
          style={{
            fontSize: 120,
            fontWeight: 800,
            color: '#fff',
            textShadow: '0 6px 30px rgba(0,0,0,0.6)',
            background: 'rgba(0,0,0,0.35)',
            padding: '20px 60px',
            borderRadius: 30,
          }}
        >
          একটি পরিবারের গল্প
        </div>
      </AbsoluteFill>

      {/* closing message */}
      <AbsoluteFill style={{justifyContent: 'flex-start', alignItems: 'center', paddingTop: 70, opacity: endOpacity}}>
        <div
          style={{
            fontSize: 76,
            fontWeight: 800,
            color: '#fff',
            textShadow: '0 4px 20px rgba(0,0,0,0.6)',
            background: 'rgba(194,65,93,0.85)',
            padding: '14px 50px',
            borderRadius: 26,
          }}
        >
          পরিবারই সবচেয়ে বড় আশ্রয়
        </div>
      </AbsoluteFill>

      {/* subtitles */}
      {cue && (
        <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 50, opacity: cueOpacity}}>
          <div
            style={{
              background: 'rgba(0,0,0,0.62)',
              borderRadius: 24,
              padding: '16px 40px',
              maxWidth: 1650,
              textAlign: 'center',
              color: '#fff',
              fontSize: 54,
              fontWeight: 600,
              lineHeight: 1.45,
            }}
          >
            {cue.lines.map((l, i) => (
              <div key={i}>{l}</div>
            ))}
          </div>
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};
