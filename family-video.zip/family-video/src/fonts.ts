import {loadFont} from '@remotion/google-fonts/NotoSansBengali';

const {fontFamily} = loadFont('normal', {
  weights: ['600', '800'],
  subsets: ['bengali', 'latin'],
});

export {fontFamily};
