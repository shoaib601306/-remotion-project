# Family video (Remotion, 1920x1080, 30fps, 96s)

## Codespace-e chalate
```bash
npm install
npm run still      # ekta test frame -> out/test.png (age eta dekhe nin)
npm run render     # full video      -> out/family.mp4
```
Render hoye gele `out/family.mp4` file-ta VS Code-er file list theke right-click -> Download.

Preview dekhte chaile: `npm run preview` (port 3000 forward hobe).

Chrome-er library error dile:
```bash
sudo apt-get update && sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev libasound2 libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libatk-bridge2.0-0 libpango-1.0-0 libcairo2 libcups2
```

## Kothay ki change korben
- `public/voice.mp3` — voice (change korle `src/Root.tsx`-e durationInFrames = seconds x 30 kore den)
- `src/subs.ts` — subtitle text o timing
- `src/Video.tsx` — `speakers` list (ke kokhon kotha bolche), character position/mood, colors
- `src/Person.tsx` — character-er chehara
