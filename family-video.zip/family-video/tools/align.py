# Aligns caption phrases to the narration using silence detection. Output: JSON list.
import re, subprocess, json, sys
MP3 = sys.argv[1]
out = subprocess.run(['ffmpeg','-hide_banner','-i',MP3,'-af','silencedetect=noise=-32dB:d=0.18','-f','null','-'],capture_output=True,text=True).stderr
dur = float(re.search(r'Duration: (\d+):(\d+):([\d.]+)', out).group(1))*3600
m = re.search(r'Duration: (\d+):(\d+):([\d.]+)', out); dur = int(m[1])*3600+int(m[2])*60+float(m[3])
st = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', out)]
en = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', out)]
sil = [(a,b) for a,b in zip(st,en) if b-a>=0.18 and b>0.5]
# (who, text, hidden)
P = [
 (None,'একটি {পরিবারের} গল্প।',0),
 (None,'রাফি সারাদিন {mobile} নিয়ে\nব্যস্ত থাকে।',0),
 (None,'পরিবারের কারো সঙ্গে\nঠিকমতো কথা বলে না।',0),
 (None,'একদিন তার মা\nতাকে কিছু বললেন।',0),
 ('মা','রাফি, সারাদিন {mobile}\nনিয়ে পড়ে থাকিস?',0),
 ('মা','সংসারের কোনো কাজে\nসাহায্য করিস না কেন?',0),
 ('রাফি','মা, একটু শান্তিতে\nথাকতে দাও তো।',0),
 ('রাফি','সারাদিন শুধু\nবকাবকি করো।',0),
 ('ছোট ভাই/বোন','ভাইয়া, মায়ের সঙ্গে এভাবে\nকথা বলছো কেন?',0),
 ('রাফি','তুমি {চুপ} করো।',0),
 ('রাফি','তোমার এত কথা\nবলতে হবে না।',0),
 (None,'ঠিক তখনই office থেকে\nবাড়ি ফিরলেন {বাবা}।',0),
 (None,'ঘরের এমন পরিস্থিতি দেখে\nতিনি চিন্তিত হয়ে পড়লেন।',0),
 ('বাবা','কি হয়েছে?',0),
 ('বাবা','ঘরে ঢুকতেই দেখি সবাই\nসবার সঙ্গে ঝগড়া করছে।',0),
 ('মা','তোমার ছেলেকে কিছু বলো।',0),
 ('মা','সে এখন আর কারো\nকথা শুনতে চায় না।',0),
 ('বাবা','রাফি, বাবা এদিকে আসো।',0),
 ('বাবা','একটা কথা মনে রেখো,',0),
 ('বাবা','টাকা দিয়ে অনেক কিছু\nকেনা যায়, কিন্তু',0),
 ('বাবা','পরিবারের {ভালোবাসা}\nকেনা যায় না।',0),
 ('বাবা','আজ তুমি মায়ের সঙ্গে\nখারাপ ব্যবহার করছো।',0),
 ('বাবা','কিন্তু একদিন বুঝবে',0),
 ('বাবা','মায়ের এই বকাবকির মধ্যেও\nকতটা {ভালোবাসা} লুকিয়ে আছে।',0),
 (None,'বাবার কথা শুনে রাফি\nনিজের {ভুল} বুঝতে পারল।',0),
 ('রাফি','মা, আমাকে {ক্ষমা}\nকরে দাও।',0),
 ('রাফি','আর কখনো তোমার সঙ্গে\nখারাপ ব্যবহার করব না।',0),
 ('ছোট ভাই/বোন','বাবা, মা-বাবা কখনো সন্তানের\nউপর রাগ পুষে রাখে না।',0),
 ('ছোট ভাই/বোন','তুমি ভালো মানুষ হলেই\nআমাদের সবচেয়ে বেশি আনন্দ।',0),
 (None,'মনে রেখো, একটি সুন্দর পরিবার\nগড়ে ওঠে {ভালোবাসা},',0),
 (None,'{সম্মান} এবং পারস্পরিক\n{সহযোগিতার} মাধ্যমে।',0),
 (None,'পৃথিবীতে অনেক কিছু হারিয়ে\nআবার ফিরে পাওয়া যায়।',0),
 (None,'কিন্তু পরিবারের সঙ্গে\nকাটানো সুন্দর মুহূর্তগুলো',0),
 (None,'আর ফিরে আসে না।',0),
 (None,'তাই সময় থাকতে\nপরিবারকে {ভালোবাসুন}।',0),
 (None,'মা-বাবাকে {সম্মান} করুন।',0),
 (None,'কারণ পরিবারই মানুষের\nসবচেয়ে বড় {আশ্রয়}।',0),
]

SRT = sys.argv[2]
def tsec(x):
    h,mi,r=x.split(':'); sec,ms=r.split(','); return int(h)*3600+int(mi)*60+int(sec)+int(ms)/1000
blocks=[]
for b in re.split(r'\n\s*\n', open(SRT,encoding='utf-8').read().strip()):
    L=b.split('\n'); a,e=L[1].split(' --> '); blocks.append((tsec(a),tsec(e),''.join(L[2:])))
norm=lambda t: re.sub(r'[\s{}\-]','',t)
F=''.join(norm(b[2]) for b in blocks)
anch=[(0,0.12)]; c=0
for a,e,t in blocks:
    c+=len(norm(t)); anch.append((c,e))
def time_at(ci):
    for (c0,t0),(c1,t1) in zip(anch,anch[1:]):
        if ci<=c1: return t0+(t1-t0)*(ci-c0)/max(1,c1-c0)
    return anch[-1][1]
pos=0; cb=[]
for p in P:
    n=norm(p[1])
    assert F[pos:pos+len(n)]==n, ('mismatch', p[1], F[pos:pos+len(n)])
    cb.append(pos); pos+=len(n)
cb.append(pos)
bt=[time_at(x) for x in cb]
starts=bt[:-1]; ends=bt[1:]
ends=list(ends); starts=list(starts)
for i in range(1,len(P)):
    b=bt[i]
    best=min(sil,key=lambda q:abs((q[0]+q[1])/2-b))
    if abs((best[0]+best[1])/2-b)<=0.6:
        ends[i-1]=best[0]; starts[i]=best[1]
    else:
        ends[i-1]=b-0.03; starts[i]=b
ends[-1]=min(ends[-1],dur)
items=[{'s':round(starts[i],2),'e':round(ends[i],2),'who':p[0],'t':p[1],'hid':p[2]} for i,p in enumerate(P)]
print(json.dumps({'dur':dur,'items':items},ensure_ascii=False))
