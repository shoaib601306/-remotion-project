import fs from "node:fs";
const out = "public/art";

// ---------- characters (viewBox 400x700, transparent bg) ----------
const mouth = {
  neutral: `<path d="M178 190 Q200 196 222 190" stroke="#5a2a20" stroke-width="5" fill="none" stroke-linecap="round"/>`,
  sad: `<path d="M178 197 Q200 182 222 197" stroke="#5a2a20" stroke-width="5" fill="none" stroke-linecap="round"/>`,
  happy: `<path d="M174 184 Q200 212 226 184 Z" fill="#7a2a2a" stroke="#5a2a20" stroke-width="4" stroke-linejoin="round"/>`,
  worried: `<path d="M180 195 Q190 188 200 194 Q210 200 220 193" stroke="#5a2a20" stroke-width="5" fill="none" stroke-linecap="round"/>`,
};
const brows = {
  neutral: `<path d="M158 122 H186 M214 122 H242" stroke="#2b1a14" stroke-width="6" stroke-linecap="round"/>`,
  sad: `<path d="M158 126 L186 116 M242 126 L214 116" stroke="#2b1a14" stroke-width="6" stroke-linecap="round"/>`,
  happy: `<path d="M158 118 Q172 110 186 118 M214 118 Q228 110 242 118" stroke="#2b1a14" stroke-width="6" fill="none" stroke-linecap="round"/>`,
  worried: `<path d="M158 126 L186 114 M242 126 L214 114" stroke="#2b1a14" stroke-width="6" stroke-linecap="round"/>`,
};
const eyes = `<ellipse cx="172" cy="145" rx="8" ry="10" fill="#1d1210"/><ellipse cx="228" cy="145" rx="8" ry="10" fill="#1d1210"/><circle cx="175" cy="141" r="3" fill="#fff"/><circle cx="231" cy="141" r="3" fill="#fff"/>`;

function head({ skin, hair = "short", hairColor = "#1b1210", mood = "neutral", extra = "" }) {
  const hairBack = hair === "long" ? `<path d="M118 150 Q112 60 200 62 Q290 60 282 150 L292 330 Q200 350 108 330 Z" fill="${hairColor}"/>` : "";
  const hairTop = {
    short: `<path d="M126 135 Q122 66 200 64 Q278 66 274 135 Q262 100 200 98 Q138 100 126 135Z" fill="${hairColor}"/>`,
    spiky: `<path d="M124 138 L128 78 L152 96 L170 62 L196 90 L226 60 L246 94 L274 80 L276 138 Q262 104 200 102 Q138 104 124 138Z" fill="${hairColor}"/>`,
    grey: `<path d="M130 132 Q128 76 200 74 Q272 76 270 132 Q258 108 200 106 Q142 108 130 132Z" fill="#cfcfcf"/>`,
    bun: `<circle cx="200" cy="52" r="30" fill="${hairColor}"/><path d="M128 138 Q124 70 200 68 Q276 70 272 138 Q256 98 200 96 Q144 98 128 138Z" fill="${hairColor}"/>`,
    cap: `<path d="M126 128 Q124 66 200 64 Q276 66 274 128Z" fill="#2d6a9f"/><path d="M262 118 Q310 118 318 134 Q290 138 262 132Z" fill="#245580"/>`,
  }[hair];
  return `${hairBack}
  <rect x="180" y="205" width="40" height="40" fill="${skin}"/>
  <ellipse cx="200" cy="150" rx="74" ry="82" fill="${skin}"/>
  <ellipse cx="127" cy="152" rx="11" ry="16" fill="${skin}"/><ellipse cx="273" cy="152" rx="11" ry="16" fill="${skin}"/>
  ${hairTop}${eyes}${brows[mood]}
  <path d="M200 152 Q194 172 204 172" stroke="#00000030" stroke-width="4" fill="none" stroke-linecap="round"/>
  ${mouth[mood]}${extra}`;
}
const legs = (c, shoe = "#3b2a22", len = 220) => `
  <rect x="152" y="455" width="45" height="${len}" rx="14" fill="${c}"/><rect x="203" y="455" width="45" height="${len}" rx="14" fill="${c}"/>
  <ellipse cx="170" cy="${455 + len + 6}" rx="34" ry="14" fill="${shoe}"/><ellipse cx="230" cy="${455 + len + 6}" rx="34" ry="14" fill="${shoe}"/>`;
const arms = (c, skin, sad) => sad
  ? `<path d="M118 262 Q90 350 112 430" stroke="${c}" stroke-width="46" stroke-linecap="round" fill="none"/><path d="M282 262 Q310 350 288 430" stroke="${c}" stroke-width="46" stroke-linecap="round" fill="none"/><circle cx="112" cy="440" r="22" fill="${skin}"/><circle cx="288" cy="440" r="22" fill="${skin}"/>`
  : `<path d="M118 262 Q84 350 100 440" stroke="${c}" stroke-width="46" stroke-linecap="round" fill="none"/><path d="M282 262 Q316 350 300 440" stroke="${c}" stroke-width="46" stroke-linecap="round" fill="none"/><circle cx="100" cy="452" r="22" fill="${skin}"/><circle cx="300" cy="452" r="22" fill="${skin}"/>`;
const wrap = (inner) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 700" width="400" height="700">${inner}</svg>`;

const skinA = "#e0ac82", skinB = "#c98f66", skinC = "#d9a077";
const chars = {
  rakib_neutral: wrap(`${legs("#2e3a55")}<path d="M120 245 H280 L292 470 H108 Z" fill="#3d7ea6"/>${arms("#3d7ea6", skinA)}${head({ skin: skinA, hair: "short", mood: "neutral" })}`),
  rakib_sad: wrap(`${legs("#2e3a55")}<path d="M120 245 H280 L292 470 H108 Z" fill="#3d7ea6"/>${arms("#3d7ea6", skinA, true)}<g transform="translate(0,12) rotate(0)">${head({ skin: skinA, hair: "short", mood: "sad", extra: `<path d="M158 168 Q154 190 160 200" stroke="#7cc4ff" stroke-width="7" stroke-linecap="round" fill="none"/>` })}</g>`),
  rakib_happy: wrap(`${legs("#2e3a55")}<path d="M120 245 H280 L292 470 H108 Z" fill="#3d7ea6"/>${arms("#3d7ea6", skinA)}${head({ skin: skinA, hair: "short", mood: "happy" })}`),
  father_sad: wrap(`${legs("#e8e2d0", "#5a4636")}<path d="M116 245 H284 L300 520 H100 Z" fill="#e8e2d0"/><path d="M200 245 V520" stroke="#cfc8b2" stroke-width="3"/>${[290, 340, 390].map(y => `<circle cx="200" cy="${y}" r="5" fill="#b9a46a"/>`).join("")}${arms("#e8e2d0", skinB, true)}${head({ skin: skinB, hair: "grey", mood: "worried", extra: `<path d="M170 178 Q200 168 230 178 Q220 190 200 186 Q180 190 170 178Z" fill="#8a8a8a"/><path d="M136 170 Q140 200 170 214 M264 170 Q260 200 230 214" stroke="#9a9a9a" stroke-width="0" fill="none"/>` })}`),
  mother_sad: wrap(`<path d="M104 245 H296 L330 660 H70 Z" fill="#b8344a"/><path d="M104 245 H296 L316 360 L84 360Z" fill="#a02b40"/><path d="M296 245 Q230 330 130 380 L120 420 Q250 380 300 260Z" fill="#e8b94a" opacity=".9"/>${arms("#b8344a", skinC, true)}${head({ skin: skinC, hair: "bun", mood: "sad", extra: `<circle cx="200" cy="124" r="6" fill="#c0392b"/><path d="M242 168 Q246 190 240 200" stroke="#7cc4ff" stroke-width="7" stroke-linecap="round" fill="none"/>` })}`),
  hasan: wrap(`${legs("#4a4a4a")}<path d="M120 245 H280 L292 470 H108 Z" fill="#6aa84f"/><path d="M165 245 L200 290 L235 245Z" fill="#fff"/>${arms("#6aa84f", skinB)}${head({ skin: skinB, hair: "spiky", mood: "neutral" })}`),
  friend1: wrap(`${legs("#222")}<path d="M120 245 H280 L292 470 H108 Z" fill="#d9a441"/>${arms("#d9a441", skinA)}${head({ skin: skinA, hair: "cap", mood: "happy", extra: `<path d="M176 130 H224" stroke="#000" stroke-width="0"/>` })}`),
  friend2: wrap(`${legs("#5b3a8e")}<path d="M120 245 H280 L292 470 H108 Z" fill="#c0504d"/>${arms("#c0504d", skinC)}${head({ skin: skinC, hair: "short", hairColor: "#3a2418", mood: "happy", extra: `<g stroke="#222" stroke-width="5" fill="none"><circle cx="172" cy="145" r="20"/><circle cx="228" cy="145" r="20"/><path d="M192 145 H208"/></g>` })}`),
};
chars.father_happy = chars.father_sad
  .replace('mood-none','')
  .replace(/<path d="M178 197[^>]*>|<path d="M180 195[^>]*>/, mouth.happy)
  .replace(brows.worried, brows.happy);
chars.mother_happy = chars.mother_sad
  .replace(mouth.sad, mouth.happy)
  .replace(brows.sad, brows.happy)
  .replace(/<path d="M242 168[^>]*>/, "");
for (const [k, v] of Object.entries(chars)) fs.writeFileSync(`${out}/char_${k}.svg`, v);

// ---------- wall backgrounds (1080x1920) ----------
const bgw = (inner) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1080 1920" width="1080" height="1920">${inner}</svg>`;
const frame = (x, y, w, h, c1 = "#7a4b2a") => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${c1}"/><rect x="${x + 12}" y="${y + 12}" width="${w - 24}" height="${h - 24}" fill="#f4ead2"/>`;
const mini = (x, y, c, s = 1) => `<g transform="translate(${x},${y}) scale(${s})"><circle cx="0" cy="-20" r="18" fill="${c}"/><rect x="-18" y="0" width="36" height="46" rx="10" fill="#8a6a50"/></g>`;
const homeWall = (tense) => {
  const wall = tense ? "#5d5560" : "#e9c98e", wall2 = tense ? "#4b444f" : "#dcb877", floor = tense ? "#2f2a30" : "#a9744a";
  return bgw(`
  <rect width="1080" height="1920" fill="${wall}"/>
  <rect y="1380" width="1080" height="540" fill="${floor}"/>
  <rect y="1340" width="1080" height="44" fill="${wall2}"/>
  ${Array.from({ length: 9 }, (_, i) => `<rect x="${i * 120}" y="0" width="60" height="1340" fill="${wall2}" opacity=".35"/>`).join("")}
  ${Array.from({ length: 7 }, (_, i) => `<path d="M0 ${1440 + i * 80} H1080" stroke="#00000022" stroke-width="3"/>`).join("")}
  <!-- window -->
  <rect x="690" y="330" width="290" height="420" fill="#6b4226"/>
  <rect x="706" y="346" width="258" height="388" fill="${tense ? "#232c45" : "#9fd3f0"}"/>
  <path d="M835 346 V734 M706 540 H964" stroke="#6b4226" stroke-width="10"/>
  ${tense ? `<circle cx="900" cy="410" r="26" fill="#eef0c8" opacity=".85"/>` : `<circle cx="780" cy="430" r="40" fill="#ffe27a"/>`}
  <path d="M690 330 Q640 540 690 750 M980 330 Q1030 540 980 750" stroke="${tense ? "#7b4a58" : "#d97b5f"}" stroke-width="46" fill="none" opacity=".9"/>
  <!-- family photo frames -->
  ${frame(120, 330, 260, 200)}${mini(190, 440, "#d4a373", 1.1)}${mini(250, 445, "#c68d63", 1.2)}${mini(310, 450, "#d4a373", 0.9)}
  ${frame(150, 590, 170, 140)}${mini(235, 670, "#c68d63", 1)}
  <!-- calendar -->
  <rect x="420" y="360" width="150" height="200" fill="#fff" stroke="#c0392b" stroke-width="0"/><rect x="420" y="360" width="150" height="46" fill="#c0392b"/>
  ${Array.from({ length: 12 }, (_, i) => `<rect x="${432 + (i % 4) * 34}" y="${424 + Math.floor(i / 4) * 40}" width="24" height="24" fill="#ddd"/>`).join("")}
  <!-- wall clock -->
  <circle cx="500" cy="220" r="62" fill="#fff" stroke="#5a3a22" stroke-width="10"/><path d="M500 220 V176 M500 220 L530 236" stroke="#222" stroke-width="6" stroke-linecap="round"/>
  <!-- shelf with items -->
  <rect x="100" y="860" width="360" height="22" fill="#6b4226"/>
  <rect x="130" y="800" width="42" height="60" fill="#3d7ea6"/><rect x="180" y="780" width="36" height="80" fill="#c0504d"/><circle cx="380" cy="826" r="34" fill="#c98f4a"/><rect x="340" y="826" width="80" height="34" fill="#c98f4a"/>
  ${tense ? `<rect width="1080" height="1920" fill="#101018" opacity=".35"/><path d="M0 0 H1080 V1920 H0Z" fill="none"/>` : `<rect width="1080" height="1920" fill="#ffe9b0" opacity=".08"/>`}
  `);
};
fs.writeFileSync(`${out}/bg_home_happy.svg`, homeWall(false));
fs.writeFileSync(`${out}/bg_home_tense.svg`, homeWall(true));
console.log("done");
