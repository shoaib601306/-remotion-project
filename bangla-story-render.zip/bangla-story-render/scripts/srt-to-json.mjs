// Usage: node scripts/srt-to-json.mjs story.srt src/subtitles.json
import fs from "node:fs";

const [, , inFile = "story.srt", outFile = "src/subtitles.json"] = process.argv;
const raw = fs.readFileSync(inFile, "utf8").replace(/\r/g, "").replace(/^﻿/, "");
const ts = (s) => {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4].padEnd(3, "0") / 1000;
};

const cues = raw
  .split(/\n\s*\n/)
  .map((b) => b.trim().split("\n"))
  .filter((l) => l.length >= 3 && l[1].includes("-->"))
  .map((l) => {
    const [a, b] = l[1].split("-->");
    return { start: ts(a), end: ts(b), text: l.slice(2).join("\n").trim() };
  });

// Mark title cards (from "গল্পের নাম" until the intro) and the moral (from "গল্পের শিক্ষা" to the end)
let mode = "normal";
for (const c of cues) {
  if (c.text.startsWith("গল্পের নাম")) mode = "title";
  else if (c.text.startsWith("গল্পের শিক্ষা")) mode = "moral";
  else if (mode === "title" && /^একটি ভুল সিদ্ধান্ত\s*\n?কখনো/.test(c.text)) mode = "normal";
  c.kind = mode;
}

fs.writeFileSync(outFile, JSON.stringify(cues, null, 2));
console.log(`${cues.length} cues -> ${outFile}`);
