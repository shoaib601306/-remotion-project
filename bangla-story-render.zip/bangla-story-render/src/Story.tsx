import React from "react";
import {
  AbsoluteFill,
  Audio,
  Sequence,
  interpolate,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { loadFont } from "@remotion/google-fonts/HindSiliguri";
import cues from "./subtitles.json";

const { fontFamily } = loadFont("normal", {
  weights: ["500", "700"],
  subsets: ["bengali", "latin"],
});

type Cue = { start: number; end: number; text: string; kind: string };
const data = cues as Cue[];

const Background: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  const t = frame / durationInFrames;
  const hue = interpolate(t, [0, 0.5, 1], [225, 265, 215]);
  const blobs = [
    { x: 20, y: 18, s: 700, p: 0 },
    { x: 85, y: 45, s: 600, p: 2 },
    { x: 30, y: 80, s: 800, p: 4 },
  ];
  return (
    <AbsoluteFill
      style={{
        background: `linear-gradient(170deg, hsl(${hue},55%,12%) 0%, hsl(${hue + 35},50%,20%) 100%)`,
        overflow: "hidden",
      }}
    >
      {blobs.map((b, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: `${b.x + Math.sin(frame / 90 + b.p) * 6}%`,
            top: `${b.y + Math.cos(frame / 110 + b.p) * 5}%`,
            width: b.s,
            height: b.s,
            marginLeft: -b.s / 2,
            marginTop: -b.s / 2,
            borderRadius: "50%",
            background: `radial-gradient(circle, hsla(${hue + 60 + i * 25},80%,60%,0.22), transparent 65%)`,
            filter: "blur(20px)",
          }}
        />
      ))}
    </AbsoluteFill>
  );
};

const Caption: React.FC<{ cue: Cue; duration: number }> = ({ cue, duration }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const pop = spring({ frame, fps, config: { damping: 16, stiffness: 140 } });
  const fadeOut = interpolate(frame, [duration - 5, duration], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const isTitle = cue.kind === "title";
  const isMoral = cue.kind === "moral";

  return (
    <AbsoluteFill style={{ justifyContent: "center", alignItems: "center", padding: 70 }}>
      <div
        style={{
          fontFamily,
          fontWeight: isTitle || isMoral ? 700 : 500,
          fontSize: isTitle ? 104 : isMoral ? 88 : 80,
          lineHeight: 1.5,
          textAlign: "center",
          whiteSpace: "pre-line",
          color: isTitle ? "#ffd86b" : isMoral ? "#8ff0c0" : "#ffffff",
          textShadow: "0 6px 30px rgba(0,0,0,0.55)",
          opacity: pop * fadeOut,
          transform: `translateY(${(1 - pop) * 40}px) scale(${0.94 + pop * 0.06})`,
          ...(isMoral
            ? {
                background: "rgba(255,255,255,0.08)",
                border: "2px solid rgba(143,240,192,0.45)",
                borderRadius: 40,
                padding: "50px 56px",
              }
            : {}),
        }}
      >
        {cue.text}
      </div>
    </AbsoluteFill>
  );
};

const Progress: React.FC = () => {
  const frame = useCurrentFrame();
  const { durationInFrames } = useVideoConfig();
  return (
    <div
      style={{
        position: "absolute",
        left: 60,
        right: 60,
        bottom: 90,
        height: 10,
        borderRadius: 5,
        background: "rgba(255,255,255,0.18)",
      }}
    >
      <div
        style={{
          width: `${(frame / durationInFrames) * 100}%`,
          height: "100%",
          borderRadius: 5,
          background: "linear-gradient(90deg,#ffd86b,#8ff0c0)",
        }}
      />
    </div>
  );
};

export const Story: React.FC = () => {
  const { fps } = useVideoConfig();
  return (
    <AbsoluteFill>
      <Background />
      <Audio src={staticFile("narration.mp3")} />
      {data.map((cue, i) => {
        const from = Math.round(cue.start * fps);
        // hold each caption until the next one starts (no flicker in gaps)
        const next = data[i + 1]?.start ?? cue.end + 0.4;
        const dur = Math.max(6, Math.round(next * fps) - from);
        return (
          <Sequence key={i} from={from} durationInFrames={dur}>
            <Caption cue={cue} duration={dur} />
          </Sequence>
        );
      })}
      <Progress />
    </AbsoluteFill>
  );
};
