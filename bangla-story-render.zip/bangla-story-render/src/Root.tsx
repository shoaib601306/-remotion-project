import { Composition } from "remotion";
import { Story } from "./Story";

export const FPS = 30;
// narration.mp3 = 82.83s + 0.7s tail
export const DURATION_IN_FRAMES = Math.ceil((82.84 + 0.7) * FPS);

export const Root: React.FC = () => (
  <Composition
    id="Story"
    component={Story}
    durationInFrames={DURATION_IN_FRAMES}
    fps={FPS}
    width={1080}
    height={1920}
  />
);
