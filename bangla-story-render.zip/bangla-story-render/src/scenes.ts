// সময় সেকেন্ডে। x = ক্যারেক্টারের মাঝখানের অবস্থান (ভিডিওর প্রস্থ 1080)
export type SceneChar = { name: string; x: number };
export type Scene = { from: number; to: number; bg: "happy" | "tense" | null; chars: SceneChar[] };

export const scenes: Scene[] = [
  { from: 0, to: 11.2, bg: null, chars: [] },
  { from: 11.2, to: 14.3, bg: "happy", chars: [{ name: "rakib_neutral", x: 540 }] },
  { from: 14.3, to: 20.7, bg: "happy", chars: [{ name: "rakib_neutral", x: 330 }, { name: "father_happy", x: 760 }] },
  { from: 20.7, to: 32, bg: "happy", chars: [{ name: "rakib_neutral", x: 250 }, { name: "friend1", x: 600 }, { name: "friend2", x: 880 }] },
  { from: 32, to: 36.8, bg: "happy", chars: [{ name: "rakib_happy", x: 250 }, { name: "friend1", x: 600 }, { name: "friend2", x: 880 }] },
  { from: 36.8, to: 40.7, bg: "tense", chars: [{ name: "rakib_sad", x: 540 }] },
  { from: 40.7, to: 46.1, bg: "tense", chars: [{ name: "rakib_sad", x: 220 }, { name: "father_sad", x: 560 }, { name: "mother_sad", x: 880 }] },
  { from: 46.1, to: 59.7, bg: "tense", chars: [{ name: "rakib_sad", x: 330 }, { name: "hasan", x: 760 }] },
  { from: 59.7, to: 63, bg: "tense", chars: [{ name: "rakib_sad", x: 540 }] },
  { from: 63, to: 71.5, bg: "happy", chars: [{ name: "rakib_neutral", x: 220 }, { name: "father_happy", x: 560 }, { name: "mother_happy", x: 880 }] },
  { from: 71.5, to: 99, bg: "happy", chars: [{ name: "rakib_happy", x: 220 }, { name: "father_happy", x: 560 }, { name: "mother_happy", x: 880 }] },
];
