# Bangla Story Video (Remotion)

নিচের ধাপে Codespace-এ রেন্ডার করুন:

```bash
npm install          # devcontainer থাকলে অটো হয়ে যায়
npm run start        # (ঐচ্ছিক) Studio-তে প্রিভিউ
npm run render       # -> out/story.mp4  (1080x1920, 30fps)
npm run render:fast  # -> out/story-preview.mp4 (দ্রুত, ছোট প্রিভিউ)
```

- অডিও: `public/narration.mp3`
- সাবটাইটেল: `story.srt` → `npm run subs` চালালে `src/subtitles.json` আপডেট হয়
- আউটপুট ডাউনলোড: Codespace-এ `out/story.mp4` এ রাইট-ক্লিক → Download
- ফন্ট: Hind Siliguri (Google Fonts থেকে অটো লোড, ইন্টারনেট লাগবে)
- Chromium এর লাইব্রেরি না পেলে: `npx remotion browser ensure`
