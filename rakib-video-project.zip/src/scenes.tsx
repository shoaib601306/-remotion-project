import React from 'react';
import { interpolate } from 'remotion';
import { C, T, clamp } from './theme';
import { Stage } from './chrome';
import { Person, Mini, Bubble, PersonP } from './figures';
import * as K from './kit';
import { mouthOpen } from './kit';
const { useT, sp, breathe, blinkAt, RoomNight, DeskNight, RoomDay, RoomLiving } = K;
type SP = K.SP;
const O = K.O;
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const cl = (v: number, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const range = (t: number, a: number, b: number) => cl((t - a) / (b - a));

// ---------- characters (kept identical in every scene) ----------
const RAKIB = { skin: '#9A6238', ear: '#8A5530', shirt: '#6E96BB', pants: '#2A3550', hair: '#15110e' };
const DAD = { skin: '#946037', ear: '#84552f', shirt: '#9DBBD6', pants: '#2b2f3f', hair: '#9a9a9a', glasses: true, mustache: '#8d8d8d' };
const MOM = { skin: '#946037', ear: '#84552f', shirt: '#B5543A', pants: '#6b2f22', hair: '#15110e' };
const HASAN = { skin: '#A86D40', ear: '#97603A', shirt: '#5f9d7a', pants: '#3a4660', hair: '#1b140f' };
const FR1 = { skin: '#A86D40', ear: '#97603A', shirt: '#4a4a58', pants: '#262a3a', hair: '#1b140f' };
const FR2 = { skin: '#8A5530', ear: '#7a4a2a', shirt: '#7a5c8f', pants: '#2f2a3a', hair: '#15110e' };

type WP = Omit<PersonP, 'skin' | 'ear' | 'shirt' | 'pants' | 'hair'> & { tears?: number };
/** Mother = same Person rig + long hair / bun (+ optional tears) */
const Mom: React.FC<WP> = ({ x, y, s = 1, flip, tears, ...rest }) => (
  <g transform={`translate(${x},${y}) scale(${flip ? -s : s},${s})`}>
    <path d="M-52 -300 Q-84 -230 -50 -150 L-20 -160 L-24 -260Z" fill={MOM.hair} stroke={O} strokeWidth={3} />
    <Person {...MOM} {...rest} x={0} y={0} s={1} />
    <circle cx={-56} cy={-318} r={26} fill={MOM.hair} stroke={O} strokeWidth={3} />
    <circle cx={46} cy={-308} r={4} fill="#c0392b" />
    {tears !== undefined && [0, 1, 2].map((i) => {
      const p = ((tears + i * 9) % 27) / 27;
      return <ellipse key={i} cx={40 + i * 3} cy={-262 + p * 90} rx={5} ry={8} fill="#8fd0f0" stroke={O} strokeWidth={1.5} opacity={1 - p * 0.7} />;
    })}
  </g>
);

const Heart: React.FC<{ x: number; y: number; k?: number; fill?: string; rot?: number }> = ({ x, y, k = 1, fill = '#D8453A', rot = 0 }) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${k})`}>
    <path d="M0 52 C-96 -6 -64 -86 0 -44 C64 -86 96 -6 0 52Z" fill={fill} stroke={O} strokeWidth={4} strokeLinejoin="round" />
    <ellipse cx={-34} cy={-30} rx={13} ry={8} fill="#fff" opacity={0.45} transform="rotate(-30 -34 -30)" />
  </g>
);
const Coin: React.FC<{ x: number; y: number; r?: number; rot?: number }> = ({ x, y, r = 16, rot = 1 }) => (
  <g transform={`translate(${x},${y})`}>
    <ellipse rx={r * Math.abs(rot)} ry={r} fill="#E8B84A" stroke={O} strokeWidth={2.5} />
    <ellipse rx={r * 0.62 * Math.abs(rot)} ry={r * 0.62} fill="none" stroke="#b5832a" strokeWidth={2} />
  </g>
);
const PhoneG: React.FC<{ x: number; y: number; k?: number; rot?: number; glow?: boolean; label?: string; crack?: boolean }> = ({ x, y, k = 1, rot = 0, glow, label = 'Betting', crack }) => (
  <g transform={`translate(${x},${y}) rotate(${rot}) scale(${k})`}>
    {glow && <circle r={120} fill="#7dffb0" opacity={0.2} />}
    <rect x={-45} y={-80} width={90} height={160} rx={14} fill="#1f1a17" stroke={O} strokeWidth={4} />
    <rect x={-38} y={-68} width={76} height={132} rx={8} fill="#1d6f4e" />
    <rect x={-38} y={-68} width={76} height={40} rx={8} fill="#2a9a6c" />
    <text y={-40} textAnchor="middle" fontFamily="Hind" fontWeight={700} fontSize={17} fill="#fff">{label}</text>
    <rect x={-26} y={-14} width={52} height={20} rx={10} fill="#E8B84A" />
    <rect x={-26} y={16} width={52} height={20} rx={10} fill="#C8451E" />
    <circle cx={0} cy={50} r={6} fill="#ffffff55" />
    {crack && <path d="M-12 -68 L2 -30 L-10 0 L8 30 L-2 64" stroke="#fff" strokeWidth={2.5} fill="none" />}
  </g>
);
const Sun: React.FC<{ x: number; y: number; r: number; f: number }> = ({ x, y, r, f }) => (
  <g transform={`translate(${x},${y})`}>
    <g transform={`rotate(${f * 0.4})`}>
      {Array.from({ length: 12 }).map((_, i) => (
        <rect key={i} x={-4} y={-r - 26} width={8} height={20} rx={4} fill="#F2B84A" transform={`rotate(${i * 30})`} />
      ))}
    </g>
    <circle r={r} fill="#F7C95A" stroke={O} strokeWidth={3} />
  </g>
);
const Floor: React.FC<{ c?: string; y?: number }> = ({ c = '#D3C7B1', y = 606 }) => (
  <>
    <rect y={y} width={540} height={960 - y} fill={c} />
    <rect y={y - 4} width={540} height={6} fill="#00000018" />
  </>
);
const Sky: React.FC<{ a?: string; b?: string }> = ({ a = '#BFD9E6', b = '#EAF2EE' }) => (
  <>
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={a} /><stop offset="1" stopColor={b} /></linearGradient>
    </defs>
    <rect width={540} height={960} fill="url(#sky)" />
  </>
);
const Cloud: React.FC<{ x: number; y: number; s?: number; c?: string }> = ({ x, y, s = 1, c = '#fff' }) => (
  <g transform={`translate(${x},${y}) scale(${s})`} fill={c}>
    <ellipse cx={0} cy={0} rx={46} ry={22} /><ellipse cx={-30} cy={6} rx={30} ry={18} /><ellipse cx={30} cy={8} rx={34} ry={18} /><ellipse cx={8} cy={-14} rx={28} ry={20} />
  </g>
);
const Table: React.FC<{ y?: number }> = ({ y = 520 }) => (
  <>
    <rect x={50} y={y} width={440} height={16} rx={6} fill="#8c6a4f" stroke={O} strokeWidth={3} />
    <rect x={70} y={y + 16} width={16} height={130} fill="#6b4a32" />
    <rect x={454} y={y + 16} width={16} height={130} fill="#6b4a32" />
  </>
);
const Plate: React.FC<{ x: number; y: number }> = ({ x, y }) => (
  <g transform={`translate(${x},${y})`}>
    <ellipse rx={34} ry={9} fill="#F6EFE8" stroke={O} strokeWidth={2.5} />
    <ellipse rx={20} ry={6} cy={-3} fill="#fffdf6" />
  </g>
);

// ---------- scenes ----------

/** 0.0-5.2  title card: family, then a crack splits them */
export const S0: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const a = sp(lf(0.1)), b = sp(lf(1.25));
  const crack = range(t, 3.1, 3.5);
  const split = sp(lf(3.2), { damping: 12, stiffness: 90, mass: 1 });
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <rect x={50} y={140} width={440} height={200} rx={28} fill="#F6EFE8" stroke={O} strokeWidth={4} opacity={Math.min(1, a)} />
      <text x={270} y={196} textAnchor="middle" fontFamily="Hind" fontWeight={700} fontSize={28} fill="#8a7a68" opacity={Math.min(1, a)}>গল্পের নাম</text>
      <text x={270} y={272} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={52} fill={C.ink} opacity={Math.min(1, b)} transform={`translate(0,${(1 - Math.min(1, b)) * 18})`}>
        একটি <tspan fill={C.red}>ভুল</tspan>
      </text>
      <text x={270} y={324} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={44} fill={C.ink} opacity={Math.min(1, b)}>সিদ্ধান্ত</text>
      <rect x={30} y={640} width={480} height={10} rx={5} fill={C.tan} />
      <Mini x={150 - split * 34} y={620 + breathe(f, 1.5)} s={1.9} color="#9DBBD6" />
      <Mini x={270} y={620 + breathe(f + 10, 1.5)} s={1.9} color="#B5543A" skin="#946037" />
      <Mini x={390 + split * 34} y={620 + breathe(f + 20, 1.5)} s={1.9} color="#6E96BB" />
      <path d="M270 400 L252 450 L286 490 L256 540 L276 600 L262 660" stroke={C.red} strokeWidth={9} fill="none" strokeLinecap="round" strokeLinejoin="round" strokeDasharray={330} strokeDashoffset={330 * (1 - crack)} />
    </Stage>
  );
};

/** 5.2-11.0  happy family, heart breaks */
export const S1: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const hk = sp(lf(5.9));
  const brk = range(t, 7.7, 8.7);
  const sad = t > 7.9;
  const fall = brk * brk;
  return (
    <Stage dur={dur}>
      <RoomLiving />
      <Person x={105} y={486 + breathe(f)} s={0.7} pose="stand" {...DAD} blink={blinkAt(f)} smile={!sad} sad={sad} />
      <Mom x={240} y={486 + breathe(f + 12)} s={0.7} pose="stand" blink={blinkAt(f + 30)} smile={!sad} sad={sad} />
      <Person x={405} y={510 + breathe(f + 20)} s={0.6} pose="stand" flip {...RAKIB} blink={blinkAt(f + 50)} smile={!sad} sad={sad} />
      {brk === 0 ? (
        <g transform={`translate(0,${Math.sin(f / 9) * 4})`}><Heart x={270} y={190} k={Math.min(1, hk) * 1.1} /></g>
      ) : (
        <>
          <g transform={`translate(${-brk * 40},${fall * 70}) rotate(${-brk * 35} 270 190)`} opacity={1 - fall}>
            <path d="M270 242 C174 184 206 104 270 146 L264 168 L274 190 L266 212Z" fill="#D8453A" stroke={O} strokeWidth={4} strokeLinejoin="round" />
          </g>
          <g transform={`translate(${brk * 40},${fall * 80}) rotate(${brk * 35} 270 190)`} opacity={1 - fall}>
            <path d="M270 242 C366 184 334 104 270 146 L264 168 L274 190 L266 212Z" fill="#D8453A" stroke={O} strokeWidth={4} strokeLinejoin="round" />
          </g>
        </>
      )}
      {sad && <Cloud x={270} y={140 + (1 - range(t, 7.9, 8.6)) * -30} s={1.5} c="#8b8f99" />}
    </Stage>
  );
};

/** 11.0-14.1  Rakib in front of a simple home */
export const S2: React.FC<SP> = ({ t0, dur }) => {
  const { f } = useT(t0);
  return (
    <Stage dur={dur}>
      <Sky />
      <Sun x={90} y={190} r={34} f={f} />
      <Cloud x={200 + (f * 0.3) % 400 - 100} y={230} s={0.9} />
      <Floor c="#C9BB9F" y={640} />
      <g transform="translate(270,430)">
        <rect x={0} y={0} width={220} height={210} fill="#E5D3B0" stroke={O} strokeWidth={4} />
        <path d="M-20 0 L110 -90 L240 0Z" fill="#B5543A" stroke={O} strokeWidth={4} strokeLinejoin="round" />
        <rect x={80} y={90} width={60} height={120} rx={6} fill="#8c6a4f" stroke={O} strokeWidth={3} />
        <rect x={20} y={50} width={44} height={44} fill="#BFD9E6" stroke={O} strokeWidth={3} />
        <rect x={156} y={50} width={44} height={44} fill="#BFD9E6" stroke={O} strokeWidth={3} />
      </g>
      <Person x={150} y={440 + breathe(f)} s={0.85} pose="stand" {...RAKIB} blink={blinkAt(f)} smile />
    </Stage>
  );
};

/** 14.1-16.8  father's small shop */
export const S3: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <rect width={540} height={960} fill="#DDCFB7" />
      <Floor c="#C9BB9F" y={640} />
      <rect x={60} y={300} width={420} height={340} fill="#E9DCBF" stroke={O} strokeWidth={3} />
      {[390, 470, 550].map((y, i) => <rect key={i} x={76} y={y} width={388} height={8} fill="#8c6a4f" />)}
      {[0, 1, 2, 3, 4].map((i) => <rect key={`a${i}`} x={90 + i * 74} y={340 + (i % 2) * 6} width={46} height={50} rx={6} fill={['#C8451E', '#2C483B', '#D9A93A', '#6E96BB', '#B5543A'][i]} stroke={O} strokeWidth={2.5} />)}
      {[0, 1, 2, 3].map((i) => <rect key={`b${i}`} x={104 + i * 88} y={420} width={50} height={50} rx={10} fill={['#E8B84A', '#9DBBD6', '#C8451E', '#5f9d7a'][i]} stroke={O} strokeWidth={2.5} />)}
      <g>
        {Array.from({ length: 7 }).map((_, i) => <path key={i} d={`M${40 + i * 66} 240 h66 v50 q-33 24 -66 0Z`} fill={i % 2 ? '#F6EFE8' : '#C8451E'} stroke={O} strokeWidth={3} />)}
      </g>
      <Person x={270} y={500 + breathe(f)} s={0.78} pose="stand" {...DAD} blink={blinkAt(f)} smile />
      <rect x={40} y={520} width={460} height={130} fill="#8c6a4f" stroke={O} strokeWidth={4} />
      <rect x={40} y={520} width={460} height={14} fill="#a47b58" stroke={O} strokeWidth={3} />
      {[0, 1, 2].map((i) => {
        const k = Math.min(1, sp(lf(14.5 + i * 0.4)));
        return <rect key={i} x={90 + i * 60} y={492 + (1 - k) * -20} width={40} height={30} rx={5} fill={['#E8B84A', '#9DBBD6', '#C8451E'][i]} stroke={O} strokeWidth={2.5} opacity={k} />;
      })}
    </Stage>
  );
};

/** 16.8-20.5  happy family at a small table */
export const S4: React.FC<SP> = ({ t0, dur }) => {
  const { f } = useT(t0);
  return (
    <Stage dur={dur}>
      <RoomLiving />
      <Person x={110} y={440 + breathe(f)} s={0.7} pose="stand" {...DAD} blink={blinkAt(f)} smile />
      <Mom x={270} y={440 + breathe(f + 12)} s={0.7} pose="stand" blink={blinkAt(f + 30)} smile />
      <Person x={430} y={462 + breathe(f + 20)} s={0.6} pose="stand" flip {...RAKIB} blink={blinkAt(f + 50)} smile />
      <Table y={520} />
      <Plate x={130} y={516} /><Plate x={270} y={516} /><Plate x={410} y={516} />
      {[0, 1, 2, 3].map((i) => {
        const p = ((f + i * 22) % 88) / 88;
        return <Heart key={i} x={150 + i * 80} y={330 - p * 150} k={0.18 + 0.05 * (i % 2)} fill="#E8856B" />;
      })}
    </Stage>
  );
};

/** 20.5-26.0  friends offer online betting */
export const S5: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const pk = sp(lf(20.85), { damping: 10, stiffness: 140, mass: 0.8 });
  return (
    <Stage dur={dur}>
      <Sky a="#CFC6D8" b="#EDE3D0" />
      <Floor c="#B8A88A" y={640} />
      <Person x={118} y={470 + breathe(f)} s={0.78} pose="stand" {...RAKIB} blink={blinkAt(f)} sad={t > 24} />
      <Person x={470} y={466 + breathe(f + 15)} s={0.72} pose="stand" flip {...FR2} blink={blinkAt(f + 40)} smile />
      <Person x={350} y={470 + breathe(f + 5)} s={0.78} pose="stand" flip {...FR1} blink={blinkAt(f + 20)} smile arm="raise" hand={[120, -150]} elbow={[64, -112]} />
      <g transform={`translate(0,${Math.sin(f / 10) * 5})`}>
        <PhoneG x={262} y={235} k={Math.min(1, pk) * 1.15} rot={-6} glow />
      </g>
      {t > 23 && [0, 1, 2].map((i) => <Coin key={i} x={110 + i * 22} y={190 - ((f + i * 12) % 40) * 0.6} r={13} rot={Math.cos(f / 5 + i)} />)}
    </Stage>
  );
};

/** 26.0-28.0  Rakib does not want to */
export const S6: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const k = sp(lf(26.4), { damping: 9, stiffness: 200, mass: 0.7 });
  return (
    <Stage dur={dur}>
      <Sky a="#CFC6D8" b="#EDE3D0" />
      <Floor c="#B8A88A" y={640} />
      <g transform={`rotate(${Math.sin(f / 1.8) * 2.2} 150 640)`}>
        <Person x={150} y={470} s={0.82} pose="stand" {...RAKIB} blink={blinkAt(f)} sad arm="raise" hand={[96, -132]} elbow={[60, -60]} />
      </g>
      <Person x={440} y={470 + breathe(f)} s={0.78} pose="stand" flip {...FR1} blink={blinkAt(f + 20)} smile />
      <g transform={`translate(230,250) scale(${Math.min(1, k)})`} opacity={Math.min(1, k)}>
        <circle r={52} fill={C.red} stroke={O} strokeWidth={5} />
        <path d="M-22 -22 L22 22 M22 -22 L-22 22" stroke="#fff" strokeWidth={12} strokeLinecap="round" />
      </g>
    </Stage>
  );
};

/** 28.0-31.9  tempted, starts betting at night */
export const S7: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const roll = t < 29.6 ? 0 : (f * 14) % 360;
  return (
    <Stage dur={dur}>
      <RoomNight f={f} />
      <DeskNight />
      <Person x={150} y={560 + breathe(f)} s={0.8} {...RAKIB} blink={blinkAt(f)} smile={t > 29.6} hand={[150, -62]} elbow={[70, -90]} />
      <PhoneG x={340} y={440} k={0.6} rot={-10} glow />
      <g transform={`translate(430,478) rotate(${roll})`}>
        <rect x={-16} y={-16} width={32} height={32} rx={7} fill="#F6EFE8" stroke={O} strokeWidth={3} />
        {[[-7, -7], [7, 7], [0, 0]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r={3} fill={O} />)}
      </g>
      <Mini x={380} y={600} s={1.7} color="#4a4a58" bob={Math.sin(f / 7) * -3} />
      <Mini x={470} y={600} s={1.7} color="#7a5c8f" bob={Math.sin(f / 7 + 2) * -3} />
    </Stage>
  );
};

/** 31.9-36.6  win a little, then lose it all */
export const S8: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const up = range(t, 32.2, 33.9), down = range(t, 33.9, 36.2);
  const pts: [number, number][] = [[0, 0.1], [0.12, 0.25], [0.2, 0.18], [0.32, 0.5], [0.42, 0.78], [0.5, 0.9], [0.62, 0.55], [0.75, 0.3], [0.88, 0.12], [1, 0.02]];
  const prog = up * 0.5 + down * 0.5;
  const shown = pts.filter(([x]) => x <= prog + 1e-6);
  const line = shown.map(([x, y], i) => `${i ? 'L' : 'M'}${80 + x * 380} ${440 - y * 240}`).join(' ');
  const lose = down > 0;
  const coinsLeft = Math.round(lerp(8, 0, down));
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <rect x={50} y={160} width={440} height={320} rx={22} fill="#F6EFE8" stroke={O} strokeWidth={4} />
      {[0, 1, 2, 3].map((i) => <path key={i} d={`M80 ${200 + i * 66} H460`} stroke="#d9cbb2" strokeWidth={2} />)}
      <path d={line} fill="none" stroke={lose ? C.red : C.teal} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />
      <path d={lose ? 'M250 190 l0 30 M236 208 l14 16 l14 -16' : 'M400 190 l0 -2'} stroke={C.red} strokeWidth={8} fill="none" strokeLinecap="round" />
      <text x={86} y={198} fontFamily="Hind" fontWeight={700} fontSize={22} fill={up > 0.9 && !lose ? C.teal : '#8a7a68'}>{up < 1 || !lose ? '▲' : ''}</text>
      <rect x={30} y={640} width={480} height={10} rx={5} fill={C.tan} />
      {Array.from({ length: 8 }).map((_, i) => (
        <g key={i} opacity={i < coinsLeft ? 1 : 0}>
          <Coin x={190 + i * 22} y={620 - (i % 2) * 6} r={19} />
        </g>
      ))}
      <Person x={90} y={560 + breathe(f)} s={0.5} pose="stand" {...RAKIB} blink={blinkAt(f)} smile={!lose} sad={lose} />
    </Stage>
  );
};

/** 36.6-40.4  saved money leaves the jar */
export const S9: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const N = 10;
  const left = (i: number) => range(t, 37.3 + i * 0.22, 38.2 + i * 0.22);
  const remaining = Array.from({ length: N }).filter((_, i) => left(i) < 0.05).length;
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <Floor c="#C9BB9F" y={640} />
      <g>
        <rect x={150} y={290} width={170} height={300} rx={34} fill="#cfe6ee" opacity={0.55} stroke={O} strokeWidth={5} />
        <rect x={170} y={262} width={130} height={36} rx={12} fill="#8c6a4f" stroke={O} strokeWidth={4} />
        <rect x={158} y={590 - remaining * 22} width={154} height={remaining * 22} fill="#e8b84a" opacity={0.0} />
        {Array.from({ length: N }).map((_, i) => {
          const k = left(i);
          if (k > 0.98) return null;
          const x0 = 235 + ((i % 3) - 1) * 40, y0 = 560 - Math.floor(i / 3) * 40;
          const x = lerp(x0, 450, k), y = lerp(y0, 330, k) - Math.sin(k * Math.PI) * 120;
          return <Coin key={i} x={x} y={y} r={19} rot={Math.cos(f / 3 + i)} />;
        })}
      </g>
      <PhoneG x={450} y={350} k={0.75} rot={8} glow />
      <Person x={70} y={560 + breathe(f)} s={0.55} pose="stand" {...RAKIB} blink={blinkAt(f)} sad />
    </Stage>
  );
};

/** 40.4-42.5  trouble at home */
export const S10: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const talk = Math.floor(f / 5) % 2 === 0;
  const flash = (f % 40) < 3;
  return (
    <Stage dur={dur}>
      <RoomLiving />
      <rect width={540} height={960} fill="#1c1d33" opacity={0.28} />
      <Cloud x={150} y={150} s={1.5} c="#6f7380" /><Cloud x={400} y={170} s={1.7} c="#5d6170" />
      <path d="M280 180 L250 240 L282 240 L255 310" stroke={flash ? '#fff7b0' : '#F2B84A'} strokeWidth={10} fill="none" strokeLinejoin="round" strokeLinecap="round" opacity={flash ? 1 : 0.65} />
      <Person x={130} y={486 + breathe(f)} s={0.75} pose="stand" {...DAD} blink={blinkAt(f)} mouth={talk} sad arm="raise" hand={[110, -140]} elbow={[64, -100]} />
      <Mom x={420} y={486 + breathe(f + 9)} s={0.75} pose="stand" flip blink={blinkAt(f + 30)} mouth={!talk} sad arm="raise" hand={[110, -140]} elbow={[64, -100]} />
      <Person x={290} y={540 + breathe(f + 20)} s={0.5} pose="stand" {...RAKIB} blink={blinkAt(f + 50)} sad />
    </Stage>
  );
};

/** 42.5-44.2  father's disappointment */
export const S11: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const b = sp(lf(42.9));
  return (
    <Stage dur={dur}>
      <RoomLiving />
      <rect width={540} height={960} fill="#1c1d33" opacity={0.2} />
      <Floor c="#B6A789" y={640} />
      <Person x={230} y={500 + breathe(f, 1.2)} s={0.95} pose="stand" {...DAD} blink={blinkAt(f)} sad hand={[44, -238]} elbow={[74, -110]} />
      <Cloud x={400} y={200} s={1.2} c="#7c808c" />
      <g transform={`translate(400,${240 + Math.sin(f / 8) * 3}) scale(${Math.min(1, b)})`} opacity={Math.min(1, b)}>
        <text textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={64} fill="#4a4a58">…</text>
      </g>
    </Stage>
  );
};

/** 44.2-45.8  mother crying */
export const S12: React.FC<SP> = ({ t0, dur }) => {
  const { f } = useT(t0);
  return (
    <Stage dur={dur}>
      <RoomLiving />
      <rect width={540} height={960} fill="#1c1d33" opacity={0.2} />
      <Floor c="#B6A789" y={640} />
      <Mom x={230} y={500 + breathe(f, 1.2)} s={0.95} pose="stand" blink={false} sad tears={f} hand={[44, -238]} elbow={[74, -110]} />
      <Cloud x={400} y={200} s={1.2} c="#7c808c" />
      {[0, 1, 2].map((i) => <path key={i} d={`M${370 + i * 30} 236 l-6 22`} stroke="#8fd0f0" strokeWidth={4} strokeLinecap="round" opacity={0.5 + 0.5 * Math.sin(f / 4 + i)} />)}
    </Stage>
  );
};

const Park: React.FC<{ f: number }> = ({ f }) => (
  <>
    <Sky a="#C9D8E6" b="#EEE6D3" />
    <Floor c="#B8A88A" y={640} />
    <rect x={380} y={330} width={36} height={310} fill="#6b4a32" stroke={O} strokeWidth={3} />
    <circle cx={398} cy={290} r={100} fill="#6c9a6b" stroke={O} strokeWidth={3} />
    <circle cx={340} cy={330} r={60} fill="#5c8a5c" /><circle cx={455} cy={335} r={58} fill="#5c8a5c" />
    <Cloud x={120 + (f * 0.25) % 300} y={220} s={0.8} />
  </>
);

/** 45.8-49.4  Hasan speaks to Rakib */
export const S13: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  return (
    <Stage dur={dur}>
      <Park f={f} />
      <Person x={120} y={480 + breathe(f)} s={0.82} pose="stand" {...RAKIB} blink={blinkAt(f)} sad />
      <Person x={330} y={480 + breathe(f + 12)} s={0.82} pose="stand" flip {...HASAN} blink={blinkAt(f + 30)} mouth={mouthOpen('hasan', t)} arm="raise" hand={[100, -140]} elbow={[60, -70]} />
    </Stage>
  );
};

/** 49.4-52.0  money can be earned again */
export const S14: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const k = sp(lf(49.7), { damping: 10, stiffness: 130, mass: 0.8 });
  return (
    <Stage dur={dur}>
      <Park f={f} />
      <Person x={120} y={480 + breathe(f)} s={0.82} pose="stand" {...RAKIB} blink={blinkAt(f)} sad={t < 51} />
      <Person x={330} y={480 + breathe(f + 12)} s={0.82} pose="stand" flip {...HASAN} blink={blinkAt(f + 30)} mouth={mouthOpen('hasan', t)} arm="raise" hand={[100, -140]} elbow={[60, -70]} />
      <g transform={`translate(230,230) scale(${Math.min(1, k)})`} opacity={Math.min(1, k)}>
        <circle r={62} fill="#F6EFE8" stroke={O} strokeWidth={4} />
        <Coin x={0} y={0} r={32} rot={Math.cos(f / 8)} />
        <g transform={`rotate(${f * 4})`}>
          <path d="M0 -78 A78 78 0 0 1 70 -34" stroke={C.teal} strokeWidth={9} fill="none" strokeLinecap="round" />
          <path d="M58 -56 L74 -32 L48 -28" fill={C.teal} />
        </g>
      </g>
    </Stage>
  );
};

/** 52.0-56.4  trust is glass: easy to break, hard to mend */
export const S15: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const brk = range(t, 53.6, 54.2);
  const jit = t > 54.6 ? Math.sin(f * 1.7) * 3 : 0;
  const parts = [[-52, -30, -14], [46, -34, 16], [-30, 36, 10], [34, 40, -12]];
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      {brk === 0 ? (
        <g transform={`translate(270,330) scale(2.1)`}>
          <path d="M0 52 C-96 -6 -64 -86 0 -44 C64 -86 96 -6 0 52Z" fill="#cfe6ee" stroke="#6aa7c0" strokeWidth={4} opacity={0.9} />
          <ellipse cx={-34} cy={-30} rx={13} ry={8} fill="#fff" opacity={0.8} transform="rotate(-30 -34 -30)" />
        </g>
      ) : (
        parts.map(([dx, dy, r], i) => {
          const kk = brk * (t > 54.6 ? 0.7 : 1);
          return (
            <g key={i} transform={`translate(${270 + dx * 1.2 * (1 + kk * 1.6) + jit},${330 + dy * 1.2 * (1 + kk * 1.4) + kk * 40}) rotate(${r * kk * 3})`}>
              <path d={['M-60 -10 L-8 -60 L0 -6Z', 'M8 -60 L62 -8 L0 -6Z', 'M-62 0 L0 -2 L-6 52Z', 'M2 -2 L64 4 L6 52Z'][i]} fill="#cfe6ee" stroke="#6aa7c0" strokeWidth={3.5} strokeLinejoin="round" />
            </g>
          );
        })
      )}
      <text x={270} y={338} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={36} fill="#3f6f86" opacity={brk === 0 ? 1 : 1 - brk}>বিশ্বাস</text>
      <rect x={30} y={640} width={480} height={10} rx={5} fill={C.tan} />
      {t > 54.6 && <g opacity={Math.min(1, (t - 54.6) * 3)}><path d="M120 560 L170 520 L220 560 M330 560 L380 520 L430 560" stroke={C.red} strokeWidth={6} fill="none" strokeLinecap="round" strokeLinejoin="round" strokeDasharray="2 12" /></g>}
    </Stage>
  );
};

/** 56.4-59.5  still time: change yourself */
export const S16: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const min = t * 120, hr = t * 10;
  return (
    <Stage dur={dur}>
      <Sky a="#F6D9A8" b="#F2EAD6" />
      <Floor c="#B8A88A" y={640} />
      <g transform="translate(270,210)">
        <circle r={78} fill="#F6EFE8" stroke={O} strokeWidth={5} />
        {Array.from({ length: 12 }).map((_, i) => <rect key={i} x={-2} y={-68} width={4} height={10} fill={O} transform={`rotate(${i * 30})`} />)}
        <path d="M0 0 L0 -50" stroke={C.red} strokeWidth={6} strokeLinecap="round" transform={`rotate(${min})`} />
        <path d="M0 0 L0 -32" stroke={O} strokeWidth={7} strokeLinecap="round" transform={`rotate(${hr})`} />
        <circle r={7} fill={O} />
      </g>
      <Person x={150} y={490 + breathe(f)} s={0.82} pose="stand" {...RAKIB} blink={blinkAt(f)} smile={t > 58.2} sad={t <= 58.2} />
      <Person x={390} y={490 + breathe(f + 12)} s={0.82} pose="stand" flip {...HASAN} blink={blinkAt(f + 30)} mouth={mouthOpen('hasan', t)} arm="raise" hand={[130, -108]} elbow={[70, -80]} />
    </Stage>
  );
};

/** 59.5-63.3  his words hit deep */
export const S17: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const hits = [60.1, 60.9, 61.7];
  return (
    <Stage dur={dur} bg="#E2D6BE">
      <RoomDay />
      <Person x={190} y={480 + breathe(f, 1)} s={0.95} pose="stand" {...RAKIB} blink={blinkAt(f)} sad hand={[8, -118]} elbow={[70, -60]} />
      {hits.map((h, i) => {
        const p = range(t, h - 0.55, h);
        const y = 345 + (i - 1) * 24;
        const fade = t > h ? 0 : 1;
        return (
          <g key={i} opacity={fade * (p > 0 ? 1 : 0)} transform={`translate(${lerp(560, 280, p)},${y})`}>
            <path d="M0 0 H70 M0 0 L16 -10 M0 0 L16 10" stroke={O} strokeWidth={6} strokeLinecap="round" />
            <rect x={36} y={-14} width={34} height={28} rx={6} fill={C.card} stroke={O} strokeWidth={2.5} />
          </g>
        );
      })}
      {hits.map((h, i) => (
        <circle key={`r${i}`} cx={190} cy={365} r={lerp(12, 70, range(t, h, h + 0.5))} fill="none" stroke={C.red} strokeWidth={5} opacity={t > h ? 1 - range(t, h, h + 0.5) : 0} />
      ))}
      <Heart x={190} y={365} k={0.2 + 0.03 * Math.sin(f / 3)} />
    </Stage>
  );
};

/** 63.3-65.3  realises the mistake */
export const S18: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const bulb = sp(lf(63.8), { damping: 9, stiffness: 180, mass: 0.7 });
  const drop = range(t, 64.3, 64.8);
  return (
    <Stage dur={dur}>
      <RoomDay />
      <Person x={200} y={500 + breathe(f, 1)} s={0.95} pose="stand" {...RAKIB} blink={blinkAt(f)} hand={[104, -80]} elbow={[60, -50]} />
      <PhoneG x={296} y={448 + drop * drop * 200} k={0.38} rot={-20 + drop * 70} crack={drop > 0} />
      <g transform={`translate(240,150) scale(${Math.min(1, bulb)})`} opacity={Math.min(1, bulb)}>
        <circle r={70} fill="#ffe27a" opacity={0.4 + 0.1 * Math.sin(f / 4)} />
        <circle r={30} fill="#FFE27A" stroke={O} strokeWidth={4} />
        <rect x={-14} y={28} width={28} height={20} rx={5} fill="#b9b4a8" stroke={O} strokeWidth={3} />
        {Array.from({ length: 8 }).map((_, i) => <rect key={i} x={-2} y={-62} width={4} height={14} rx={2} fill="#F2B84A" transform={`rotate(${i * 45})`} />)}
      </g>
    </Stage>
  );
};

/** 65.3-67.2  apologises to his parents */
export const S19: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const bow = sp(f - T(65.7 - t0), { damping: 14, stiffness: 120, mass: 0.9 });
  return (
    <Stage dur={dur}>
      <RoomLiving />
      <g transform={`rotate(${Math.min(1, bow) * 18} 140 520)`}>
        <Person x={140} y={470} s={0.82} pose="stand" {...RAKIB} blink={blinkAt(f)} sad hand={[36, -130]} elbow={[60, -90]} />
      </g>
      <Person x={360} y={470 + breathe(f)} s={0.82} pose="stand" flip {...DAD} blink={blinkAt(f + 20)} sad={t < 66.2} smile={t >= 66.2} />
      <Mom x={470} y={470 + breathe(f + 10)} s={0.82} pose="stand" flip blink={blinkAt(f + 40)} sad={t < 66.2} smile={t >= 66.2} />
    </Stage>
  );
};

/** 67.2-71.2  a new honest path at sunrise */
export const S20: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const walk = range(t, 67.4, 70.8);
  const x = lerp(70, 300, walk);
  return (
    <Stage dur={dur}>
      <Sky a="#F8D79A" b="#FBEFD3" />
      <Sun x={420} y={330} r={52 + 3 * Math.sin(f / 10)} f={f} />
      <path d="M0 470 Q140 380 280 440 T540 400 V640 H0Z" fill="#9db98a" stroke="#00000020" />
      <Floor c="#C9B48A" y={600} />
      <path d="M0 640 H540" stroke="#a89470" strokeWidth={4} strokeDasharray="22 16" />
      <g transform="translate(430,430)">
        <rect x={-6} y={0} width={12} height={170} fill="#6b4a32" stroke={O} strokeWidth={3} />
        <rect x={-62} y={-52} width={124} height={56} rx={10} fill="#F6EFE8" stroke={O} strokeWidth={3.5} />
        <text y={-14} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={28} fill={C.teal}>সৎ পথ</text>
      </g>
      <Person x={x} y={440 + Math.abs(Math.sin(f / 5)) * -6} s={0.8} pose="stand" {...RAKIB} blink={blinkAt(f)} smile />
    </Stage>
  );
};

/** 71.2-73.0  lesson card */
export const S21: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const k = sp(lf(71.5));
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <g transform={`translate(270,430) scale(${Math.min(1, k)})`} opacity={Math.min(1, k)}>
        <circle r={150} fill="#ffe9a8" opacity={0.5 + 0.1 * Math.sin(f / 7)} />
        <path d="M-130 -70 Q-65 -100 0 -60 V80 Q-65 40 -130 70Z" fill="#F6EFE8" stroke={O} strokeWidth={5} strokeLinejoin="round" />
        <path d="M130 -70 Q65 -100 0 -60 V80 Q65 40 130 70Z" fill="#fffaf0" stroke={O} strokeWidth={5} strokeLinejoin="round" />
        {[0, 1, 2].map((i) => <path key={i} d={`M-100 ${-36 + i * 24} Q-65 ${-52 + i * 24} -22 ${-24 + i * 24} M22 ${-24 + i * 24} Q65 ${-52 + i * 24} 100 ${-36 + i * 24}`} stroke="#cdbfa8" strokeWidth={6} fill="none" strokeLinecap="round" />)}
        <path d="M0 -90 l8 18 l20 2 l-15 14 l5 19 l-18 -10 l-18 10 l5 -19 l-15 -14 l20 -2Z" fill="#E8B84A" stroke={O} strokeWidth={3} transform="translate(0,-60)" />
      </g>
    </Stage>
  );
};

const PillarCard: React.FC<{ y: number; text: string; k: number; icon: 'heart' | 'shield' | 'sprout' }> = ({ y, text, k, icon }) => {
  const kk = Math.min(1, k);
  return (
    <g transform={`translate(270,${y + (1 - kk) * 40}) scale(${0.9 + 0.1 * kk})`} opacity={kk}>
      <rect x={-190} y={-52} width={380} height={104} rx={24} fill="#F6EFE8" stroke={O} strokeWidth={3} />
      <circle cx={-132} cy={0} r={34} fill={icon === 'heart' ? C.red : icon === 'shield' ? C.teal : '#5f9d7a'} />
      {icon === 'heart' && <path d="M-132 14 C-160 -4 -150 -26 -132 -14 C-114 -26 -104 -4 -132 14Z" fill="#fff" />}
      {icon === 'shield' && <path d="M-148 -4 L-136 10 L-114 -14" stroke="#fff" strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" />}
      {icon === 'sprout' && <path d="M-132 16 V-4 M-132 -4 Q-152 -6 -150 -24 Q-130 -26 -132 -4 M-132 -4 Q-112 -6 -114 -24 Q-134 -26 -132 -4" stroke="#fff" strokeWidth={5} fill="none" strokeLinecap="round" />}
      <text x={-76} y={14} fontFamily="NSB" fontWeight={800} fontSize={44} fill={C.ink}>{text}</text>
    </g>
  );
};

/** 73.0-79.0  temporary joy vs. family, trust, future */
export const S22: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const joy = sp(lf(73.3));
  const shrink = 1 - range(t, 74.0, 75.2) * 0.5;
  const stamp = sp(lf(77.9), { damping: 9, stiffness: 220, mass: 0.7 });
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <g transform={`translate(270,190) scale(${Math.min(1, joy) * shrink})`} opacity={Math.min(1, joy)}>
        {Array.from({ length: 8 }).map((_, i) => <circle key={i} cx={Math.cos(i * 0.785 + f / 15) * 70} cy={Math.sin(i * 0.785 + f / 15) * 50} r={7} fill={['#C8451E', '#E8B84A', '#5f9d7a', '#6E96BB'][i % 4]} />)}
        <path d="M-40 40 L0 -50 L40 40Z" fill="#E8B84A" stroke={O} strokeWidth={4} strokeLinejoin="round" />
      </g>
      <PillarCard y={340} text="পরিবার" k={sp(lf(75.2))} icon="heart" />
      <PillarCard y={470} text="বিশ্বাস" k={sp(lf(76.2))} icon="shield" />
      <PillarCard y={600} text="ভবিষ্যৎ" k={sp(lf(77.1))} icon="sprout" />
      <g transform={`translate(270,470) rotate(-10) scale(${2.4 - 1.4 * Math.min(1, stamp)})`} opacity={Math.min(1, stamp) * 0.92}>
        <circle r={170} fill="none" stroke={C.red} strokeWidth={16} />
        <path d="M-120 -120 L120 120" stroke={C.red} strokeWidth={16} strokeLinecap="round" />
      </g>
    </Stage>
  );
};

/** 79.0-84.3  family is the greatest treasure */
export const S23: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const k = sp(lf(79.9));
  return (
    <Stage dur={dur} push={0.06}>
      <RoomLiving />
      <rect width={540} height={960} fill="#ffe9b8" opacity={0.22} />
      <Person x={120} y={476 + breathe(f)} s={0.72} pose="stand" {...DAD} blink={blinkAt(f)} smile />
      <Mom x={405} y={476 + breathe(f + 12)} s={0.72} pose="stand" flip blink={blinkAt(f + 30)} smile />
      <Person x={266} y={520 + breathe(f + 20)} s={0.6} pose="stand" {...RAKIB} blink={blinkAt(f + 50)} smile />
      <circle cx={270} cy={210} r={110} fill="#ffe27a" opacity={0.35 + 0.1 * Math.sin(f / 10)} />
      <g transform={`translate(0,${Math.sin(f / 12) * 4})`}>
        <Heart x={270} y={200} k={Math.min(1, k) * 1.2 * (1 + 0.03 * Math.sin(f / 6))} fill="#E8B84A" />
      </g>
      {[0, 1, 2, 3, 4].map((i) => {
        const a = f / 20 + i * 1.26;
        return <circle key={i} cx={270 + Math.cos(a) * 120} cy={210 + Math.sin(a) * 70} r={4} fill="#fff" opacity={0.5 + 0.5 * Math.sin(f / 5 + i)} />;
      })}
    </Stage>
  );
};

// List the scenes in time order. s/e are seconds on the final timeline; every cut sits inside a voice pause.
export const SCENES = [
  { s: 0.0, e: 5.2, C: S0 }, { s: 5.2, e: 11.0, C: S1 }, { s: 11.0, e: 14.1, C: S2 },
  { s: 14.1, e: 16.8, C: S3 }, { s: 16.8, e: 20.5, C: S4 }, { s: 20.5, e: 26.0, C: S5 },
  { s: 26.0, e: 28.0, C: S6 }, { s: 28.0, e: 31.9, C: S7 }, { s: 31.9, e: 36.6, C: S8 },
  { s: 36.6, e: 40.4, C: S9 }, { s: 40.4, e: 42.5, C: S10 }, { s: 42.5, e: 44.2, C: S11 },
  { s: 44.2, e: 45.8, C: S12 }, { s: 45.8, e: 49.4, C: S13 }, { s: 49.4, e: 52.0, C: S14 },
  { s: 52.0, e: 56.4, C: S15 }, { s: 56.4, e: 59.5, C: S16 }, { s: 59.5, e: 63.3, C: S17 },
  { s: 63.3, e: 65.3, C: S18 }, { s: 65.3, e: 67.2, C: S19 }, { s: 67.2, e: 71.2, C: S20 },
  { s: 71.2, e: 73.0, C: S21 }, { s: 73.0, e: 79.0, C: S22 }, { s: 79.0, e: 84.3, C: S23 },
];
