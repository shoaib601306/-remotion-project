#!/usr/bin/env bash
# loudness-normalise + web-optimise the Remotion output
set -e
ffmpeg -y -i out/raw.mp4 -c:v copy -af loudnorm=I=-14:TP=-1.5:LRA=11 -c:a aac -b:a 192k -movflags +faststart out/rakib_story.mp4
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate,duration -of default=nw=1 out/rakib_story.mp4
echo "Done -> out/rakib_story.mp4"
