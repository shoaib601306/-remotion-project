# রাকিবের গল্প – ভিডিও রেন্ডার প্রজেক্ট (1080×1920, 30fps)

Codespace-এ:
1. `npm install`
2. `npm run setup`    (বাংলা ফন্ট কপি + সাউন্ড ইফেক্ট তৈরি)
3. `npm run preview`  (ঐচ্ছিক: ব্রাউজারে দেখে নেওয়া)
4. `npm run render`   → চূড়ান্ত ফাইল: `out/rakib_story.mp4`

Chromium-এর লাইব্রেরি না থাকলে একবার চালান:
`sudo apt-get update && sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libgbm-dev libasound2 libxrandr2 libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libatk-bridge2.0-0 libpango-1.0-0 libcairo2 libcups2`

কাজের ফাইল: `src/data.ts` (ক্যাপশন, সময়, সাউন্ড), `src/scenes.tsx` (২৪টি দৃশ্য), `public/voice.mp3` (আপনার অডিও)।
