// Run once after `npm install`:  npm run setup
import fs from 'fs';
import { execSync } from 'child_process';
fs.mkdirSync('public/fonts', { recursive: true });
const pick = [
  ['@fontsource/hind-siliguri', 'hind-siliguri-bengali-600-normal.woff2'],
  ['@fontsource/hind-siliguri', 'hind-siliguri-bengali-700-normal.woff2'],
  ['@fontsource/noto-serif-bengali', 'noto-serif-bengali-bengali-800-normal.woff2'],
];
for (const [pkg, f] of pick) fs.copyFileSync(`node_modules/${pkg}/files/${f}`, `public/fonts/${f}`);
execSync('node gen-sfx.mjs', { stdio: 'inherit' });
console.log('Setup done. Now run: npm run render');
