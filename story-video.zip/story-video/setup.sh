#!/usr/bin/env bash
# ব্যবহার:  bash setup.sh        (ইনস্টল + রেন্ডার + অডিও ঠিক করা — সব একসাথে)
set -e
cd "$(dirname "$0")"

echo "[1/6] প্যাকেজ ইনস্টল হচ্ছে..."
npm install --no-audit --no-fund
npm install --no-audit --no-fund @fontsource/hind-siliguri @fontsource/noto-serif-bengali

echo "[2/6] বাংলা ফন্ট কপি হচ্ছে..."
mkdir -p public/fonts out
cp node_modules/@fontsource/hind-siliguri/files/hind-siliguri-bengali-600-normal.woff2 public/fonts/
cp node_modules/@fontsource/hind-siliguri/files/hind-siliguri-bengali-700-normal.woff2 public/fonts/
cp node_modules/@fontsource/noto-serif-bengali/files/noto-serif-bengali-bengali-800-normal.woff2 public/fonts/

echo "[3/6] সাউন্ড ইফেক্ট তৈরি হচ্ছে..."
node gen-sfx.mjs

echo "[4/6] ব্রাউজারের দরকারি লাইব্রেরি ইনস্টল হচ্ছে..."
(sudo apt-get update -y >/dev/null 2>&1 || true)
sudo apt-get install -y libnss3 libdbus-1-3 libatk1.0-0 libatk-bridge2.0-0 libgbm-dev libxrandr2 \
  libxkbcommon-dev libxfixes3 libxcomposite1 libxdamage1 libcups2 libpango-1.0-0 libcairo2 ffmpeg >/dev/null 2>&1 || true
(sudo apt-get install -y libasound2 >/dev/null 2>&1 || sudo apt-get install -y libasound2t64 >/dev/null 2>&1 || true)
npx remotion browser ensure

echo "[5/6] ভিডিও রেন্ডার হচ্ছে (২০-৪০ মিনিট লাগতে পারে)..."
npx remotion render src/index.ts StoryVideo out/raw.mp4 --codec=h264 --concurrency=2

echo "[6/6] অডিও ঠিক করে চূড়ান্ত MP4 বানানো হচ্ছে..."
ffmpeg -y -v error -i out/raw.mp4 -af loudnorm=I=-16:TP=-1.5:LRA=11 -c:v copy -c:a aac -b:a 192k -movflags +faststart out/story.mp4
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate -show_entries format=duration -of default=nw=1 out/story.mp4
echo "শেষ! ভিডিও: $(pwd)/out/story.mp4"
