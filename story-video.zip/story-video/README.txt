Codespaces-এ চালানোর নিয়ম:
1) এই জিপ আপলোড করুন, তারপর টার্মিনালে:  unzip story-video.zip -d story-video && cd story-video
2) চালান:  nohup bash setup.sh > setup.log 2>&1 &
3) অগ্রগতি দেখুন:  tail -n 5 setup.log
4) শেষে ভিডিও: out/story.mp4  (Explorer থেকে ডাউনলোড করুন)
