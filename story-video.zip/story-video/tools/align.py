# Aligns caption phrases to the narration using silence detection. Output: JSON list.
import re, subprocess, json, sys
MP3 = sys.argv[1]
out = subprocess.run(['ffmpeg','-hide_banner','-i',MP3,'-af','silencedetect=noise=-32dB:d=0.18','-f','null','-'],capture_output=True,text=True).stderr
dur = float(re.search(r'Duration: (\d+):(\d+):([\d.]+)', out).group(1))*3600
m = re.search(r'Duration: (\d+):(\d+):([\d.]+)', out); dur = int(m[1])*3600+int(m[2])*60+float(m[3])
st = [float(x) for x in re.findall(r'silence_start: ([\d.]+)', out)]
en = [float(x) for x in re.findall(r'silence_end: ([\d.]+)', out)]
sil = [(a,b) for a,b in zip(st,en) if b-a>=0.18 and b>0.5]
# (who, text, hidden)
P = [
 (None,'Scene এক, একটি নতুন স্বপ্ন।',1),
 (None,'রাফি একটি {চায়ের দোকানে}\nবসে মোবাইলে ব্যবসার',0),
 (None,'{পরিকল্পনা} করছে।',0),
 ('রাফি','বন্ধু হাসান, জানিস আমি\nএকটা নতুন {ব্যবসা}',0),
 ('রাফি','শুরু করতে যাচ্ছি।',0),
 ('রাফি','এবার জীবনে অনেক\nবড় কিছু করব।',0),
 ('হাসান','বাহ্, কী ব্যবসা?',0),
 ('হাসান','আমাকে সব খুলে বলো।',0),
 ('রাফি','আমি online পোশাকের\nব্যবসা করব।',0),
 ('রাফি','কোথা থেকে মাল কিনব,\nকত দামে বিক্রি করব,',0),
 ('রাফি','সব {পরিকল্পনা} তৈরি\nকরে ফেলেছি।',0),
 (None,'[হাসির শব্দ]',1),
 ('হাসান','তুই তো দেখি বড়\nব্যবসায়ী হয়ে গেছিস।',0),
 (None,'Scene দুই, পরিকল্পনার বিপদ।',1),
 (None,'কয়েকদিন পর রাফি বাজারে\nগিয়ে দেখে অন্য একজন',0),
 (None,'একই ব্যবসা শুরু করেছে।',0),
 ('রাফি','আরে,',0),
 ('রাফি','এ তো আমার ব্যবসার idea।',0),
 (None,'[শ্বাস ফেলার শব্দ]',1),
 ('রাফি','কিন্তু আমার পরিকল্পনা\nসে জানল {কীভাবে}?',0),
 (None,'হাসান এসে দাঁড়ায়।',0),
 ('রাফি','বন্ধু, আমি তোকে বিশ্বাস\nকরে সব বলেছিলাম।',0),
 ('হাসান','দেখ বন্ধু, সবাই তোমার\nপরিকল্পনা শুনে',0),
 ('হাসান','খুশি হবে এমন নয়।',0),
 ('হাসান','কেউ কেউ তোমার আগেই\nসুযোগটা কাজে লাগাতে পারে।',0),
 (None,'Scene তিন, উপলব্ধি।',1),
 ('রাফি','তাহলে কি কাউকে\nকিছু বলব না?',0),
 ('হাসান','অবশ্যই বলবি।',0),
 ('হাসান','তবে কাকে কতটুকু বলতে হয়\nসেটা বুঝতে হবে।',0),
 ('হাসান','নিজের পরিকল্পনা নিয়ে বেশি\nআলোচনা না করে',0),
 ('হাসান','কাজে {মনোযোগ} দে।',0),
 (None,'কয়েক মাস পর\nরাফির ব্যবসা {সফল} হয়।',0),
 ('হাসান','বন্ধু, এবার তো সত্যিই\nবড় ব্যবসায়ী হয়ে গেলি।',0),
 ('রাফি','কারণ এবার কথা\nকম বলেছি,',0),
 ('রাফি','{কাজ বেশি} করেছি।',0),
 (None,'Scene চার, শেষ শিক্ষা।',1),
 (None,'Voiceover,',1),
 (None,'মনে রেখো, প্রতিটি স্বপ্ন\nসবার সামনে প্রকাশ',0),
 (None,'করার প্রয়োজন নেই।',0),
 (None,'কিছু স্বপ্ন {নীরবে}\nতৈরি করতে হয়।',0),
 (None,'কারণ তোমার পরিকল্পনা\nযতটা গুরুত্বপূর্ণ,',0),
 (None,'সেটি বাস্তবায়ন করাও\nততটাই গুরুত্বপূর্ণ।',0),
 (None,'{কথা কম} বলো,\n{কাজ বেশি} করো।',0),
 (None,'তোমার সাফল্যই একদিন',0),
 (None,'তোমার হয়ে কথা বলবে।',0),
]

SRT = sys.argv[2]
def tsec(x):
    h,mi,r=x.split(':'); sec,ms=r.split(','); return int(h)*3600+int(mi)*60+int(sec)+int(ms)/1000
blocks=[]
for b in re.split(r'\n\s*\n', open(SRT,encoding='utf-8').read().strip()):
    L=b.split('\n'); a,e=L[1].split(' --> '); blocks.append((tsec(a),tsec(e),''.join(L[2:])))
norm=lambda t: re.sub(r'[\s{}]','',t)
F=''.join(norm(b[2]) for b in blocks)
anch=[(0,0.12)]; c=0
for a,e,t in blocks:
    c+=len(norm(t)); anch.append((c,e))
def time_at(ci):
    for (c0,t0),(c1,t1) in zip(anch,anch[1:]):
        if ci<=c1: return t0+(t1-t0)*(ci-c0)/max(1,c1-c0)
    return anch[-1][1]
pos=0; cb=[]
for p in P:
    n=norm(p[1])
    assert F[pos:pos+len(n)]==n, ('mismatch', p[1], F[pos:pos+len(n)])
    cb.append(pos); pos+=len(n)
cb.append(pos)
bt=[time_at(x) for x in cb]
starts=bt[:-1]; ends=bt[1:]
ends=list(ends); starts=list(starts)
for i in range(1,len(P)):
    b=bt[i]
    best=min(sil,key=lambda q:abs((q[0]+q[1])/2-b))
    if abs((best[0]+best[1])/2-b)<=0.6:
        ends[i-1]=best[0]; starts[i]=best[1]
    else:
        ends[i-1]=b-0.03; starts[i]=b
ends[-1]=min(ends[-1],dur)
items=[{'s':round(starts[i],2),'e':round(ends[i],2),'who':p[0],'t':p[1],'hid':p[2]} for i,p in enumerate(P)]
print(json.dumps({'dur':dur,'items':items},ensure_ascii=False))
