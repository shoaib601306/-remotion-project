import React from 'react';
import { interpolate } from 'remotion';
import { C, clamp } from './theme';
import { Stage } from './chrome';
import { Person, Mini, Bubble } from './figures';
import { TOTAL } from './data';
import * as K from './kit';
const { mouthOpen, useT, sp, breathe, blinkAt, RoomNight, DeskNight, DeskTop, RoomDay, Megaphone, StepCard } = K;
type SP = K.SP;
const O = K.O;

// ---- characters (same look in every scene) ----
const RAFI = { skin: '#9A6238', ear: '#8A5530', shirt: '#6E96BB', pants: '#2A3550', hair: '#15110e' };
const HASAN = { skin: '#A86D40', ear: '#97603A', shirt: '#D9A93A', pants: '#3a4660', hair: '#1b140f' };

// ---- small icons ----
const Shirt: React.FC<{ x: number; y: number; k?: number; c?: string }> = ({ x, y, k = 1, c = '#6E96BB' }) => (
  <path transform={`translate(${x},${y}) scale(${k})`} d="M-30 -22 L-12 -34 Q0 -26 12 -34 L30 -22 L22 -2 L14 -7 L14 32 L-14 32 L-14 -7 L-22 -2 Z" fill={c} stroke={O} strokeWidth={3} strokeLinejoin="round" />
);
const Box: React.FC<{ x: number; y: number; k?: number }> = ({ x, y, k = 1 }) => (
  <g transform={`translate(${x},${y}) scale(${k})`}>
    <rect x={-26} y={-22} width={52} height={44} rx={4} fill="#C9A06B" stroke={O} strokeWidth={3} />
    <rect x={-6} y={-22} width={12} height={44} fill="#E3C697" />
  </g>
);
const PriceTag: React.FC<{ x: number; y: number; k?: number }> = ({ x, y, k = 1 }) => (
  <g transform={`translate(${x},${y}) scale(${k})`}>
    <path d="M-28 -16 H12 L30 0 L12 16 H-28 Z" fill={C.red} stroke={O} strokeWidth={3} strokeLinejoin="round" />
    <circle cx={-16} cy={0} r={4} fill="#F6EFE8" />
    <text x={6} y={8} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={22} fill="#fff">৳</text>
  </g>
);
const Check: React.FC<{ x: number; y: number; k?: number }> = ({ x, y, k = 1 }) => (
  <g transform={`translate(${x},${y}) scale(${k})`}>
    <circle r={26} fill={C.teal} stroke={O} strokeWidth={3} />
    <path d="M-12 0 L-3 10 L13 -10" stroke="#fff" strokeWidth={7} fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </g>
);
const Bulb: React.FC<{ x: number; y: number; k: number }> = ({ x, y, k }) => (
  <g transform={`translate(${x},${y}) scale(${k})`} opacity={Math.min(1, k)}>
    <circle r={24} fill="#FFD76A" stroke={O} strokeWidth={3} />
    <rect x={-10} y={22} width={20} height={14} rx={4} fill="#8c7a5c" stroke={O} strokeWidth={3} />
    {[-50, 0, 50].map((a) => <path key={a} d="M0 -34 V-48" stroke="#E8B84A" strokeWidth={4} strokeLinecap="round" transform={`rotate(${a})`} />)}
  </g>
);
const Card: React.FC<{ x: number; y: number; w: number; h: number; k: number; children?: React.ReactNode }> = ({ x, y, w, h, k, children }) => (
  <g transform={`translate(${x},${y}) scale(${Math.min(1, k)})`} opacity={Math.min(1, k)}>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={22} fill="#F6EFE8" stroke={O} strokeWidth={3} />
    {children}
  </g>
);
const Table: React.FC = () => (
  <>
    <rect x={196} y={500} width={150} height={14} rx={5} fill="#6B4A32" stroke={O} strokeWidth={3} />
    <rect x={256} y={514} width={30} height={190} fill="#5a3d28" />
  </>
);

// ---- tea shop (used by scenes SA, SB1, SB2) ----
const TeaShop: React.FC<{ f: number; t: number; hasan?: number; laugh?: boolean; phone?: boolean; children?: React.ReactNode }> = ({ f, t, hasan = 1, laugh, phone, children }) => {
  const steam = (x: number, k: number) => (
    <path d={`M${x} 438 q-6 -12 0 -22 q6 -10 0 -22`} stroke="#fff" strokeWidth={3} fill="none" opacity={0.35 + 0.3 * Math.sin(f / 9 + k)} transform={`translate(0,${-((f + k * 9) % 26) * 0.5})`} />
  );
  const hx = 428 + (1 - Math.min(1, hasan)) * 230;
  return (
    <>
      <rect width={540} height={960} fill="#DDCFB7" />
      <rect x={0} y={0} width={150} height={110} fill="#aebfc4" stroke="#8d7a5c" strokeWidth={6} />
      <rect x={62} y={0} width={6} height={110} fill="#8d7a5c" />
      <rect y={610} width={540} height={350} fill="#D3C7B1" />
      <rect y={606} width={540} height={6} fill="#c2b499" />
      <path d="M0 120 Q135 150 270 120 T540 120" stroke="#6b4a32" strokeWidth={3} fill="none" />
      {[40, 130, 220, 310, 400, 490].map((x, i) => (
        <circle key={i} cx={x} cy={128 + (i % 2 ? 6 : 14)} r={8} fill="#ffd98a" opacity={0.7 + 0.3 * Math.sin(f / 10 + i)} />
      ))}
      <rect x={30} y={470} width={170} height={190} rx={34} fill="#96A5AB" />
      <rect x={340} y={470} width={170} height={190} rx={34} fill="#a9a08a" />
      <Person x={112} y={520 + breathe(f)} s={0.82} {...RAFI} blink={blinkAt(f)} mouth={mouthOpen('rafi', t)} />
      {hasan > 0 && (
        <Person x={hx} y={520 + breathe(f + 20) + (laugh ? -Math.abs(Math.sin(f / 4)) * 7 : 0)} s={0.82} flip {...HASAN} blink={blinkAt(f + 40)} mouth={mouthOpen('hasan', t)} smile={laugh} />
      )}
      <Table />
      {[222, 298].map((x, i) => (
        <g key={i} transform={`translate(${x},446)`}>
          <rect width={34} height={50} rx={5} fill="#fbf6ee" stroke={O} strokeWidth={3} />
          <rect y={12} width={34} height={9} fill="#D4601F" />
          {i === 0 && <path d="M34 12 q18 4 0 24" fill="none" stroke="#fbf6ee" strokeWidth={7} />}
        </g>
      ))}
      {steam(239, 0)}{steam(315, 3)}
      {phone && (
        <g transform="translate(200,392) rotate(-12)">
          <rect width={32} height={54} rx={6} fill="#222" stroke={O} strokeWidth={2.5} />
          <rect x={3} y={5} width={26} height={44} rx={3} fill="#9fd4ff" />
          {[0, 1, 2].map((i) => <rect key={i} x={7 + i * 7} y={40 - (i + 1) * 8} width={5} height={(i + 1) * 8} fill={C.teal} />)}
        </g>
      )}
      {children}
    </>
  );
};

// ================= দৃশ্য ১ =================
export const SA: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const cloud = sp(lf(3.4));
  return (
    <Stage dur={dur}>
      <TeaShop f={f} t={t} hasan={0} phone>
        <g transform={`translate(170,250) scale(${cloud})`} opacity={Math.min(1, cloud)}>
          <circle cx={-26} cy={96} r={9} fill="#F6EFE8" />
          <circle cx={-12} cy={66} r={15} fill="#F6EFE8" />
          <rect x={-80} y={-50} width={190} height={100} rx={46} fill="#F6EFE8" stroke={O} strokeWidth={3} />
          <Shirt x={-34} y={0} c="#6E96BB" />
          {[0, 1, 2].map((i) => <rect key={i} x={20 + i * 22} y={30 - (i + 1) * 15} width={14} height={(i + 1) * 15} rx={3} fill={C.teal} />)}
        </g>
      </TeaShop>
    </Stage>
  );
};

export const SB1: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <TeaShop f={f} t={t} hasan={sp(lf(7.5))} />
    </Stage>
  );
};

export const SB2: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const a = sp(lf(17.5)), b = sp(lf(20.1)), c = sp(lf(22.95));
  return (
    <Stage dur={dur}>
      <TeaShop f={f} t={t} laugh={t > 25.1 && t < 28.6}>
        {t < 20.0 && (
          <Card x={270} y={250} w={250} h={110} k={a}>
            <Shirt x={-70} y={0} k={1.3} c="#6E96BB" />
            <text x={20} y={10} textAnchor="middle" fontFamily="Hind" fontWeight={700} fontSize={34} fill={C.ink}>online</text>
          </Card>
        )}
        {t >= 20.0 && t < 22.9 && (
          <Card x={270} y={250} w={300} h={110} k={b}>
            <Box x={-85} y={0} k={1.3} />
            <path d="M-45 0 H25 M10 -14 L26 0 L10 14" stroke={C.ink} strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
            <PriceTag x={85} y={0} k={1.3} />
          </Card>
        )}
        {t >= 22.9 && t < 25.5 && (
          <Card x={270} y={250} w={250} h={110} k={c}>
            <Check x={-70} y={0} k={1.3} />
            <Check x={0} y={0} k={1.3} />
            <Check x={70} y={0} k={1.3} />
          </Card>
        )}
        {t > 25.3 && t < 28.6 && [0, 1, 2].map((i) => (
          <text key={i} x={380 + i * 28} y={330 - i * 16 - Math.abs(Math.sin(f / 4 + i)) * 6} fontFamily="Hind" fontWeight={700} fontSize={28} fill={C.red}>হা</text>
        ))}
      </TeaShop>
    </Stage>
  );
};

// ================= দৃশ্য ২ : বাজার =================
const MarketBg: React.FC<{ f: number }> = ({ f }) => (
  <>
    <rect width={540} height={960} fill="#cfd8dc" />
    <rect x={-20} y={300} width={140} height={330} fill="#bfa98a" />
    {[0, 1, 2].map((r) => <rect key={r} x={10} y={330 + r * 90} width={36} height={50} fill="#e9dcb8" opacity={0.85} />)}
    <rect x={0} y={610} width={540} height={350} fill="#b8a88a" />
    <rect x={0} y={606} width={540} height={8} fill="#a39475" />
    <g transform="translate(300,0)">
      <rect x={10} y={330} width={14} height={290} fill="#6B4A32" />
      <rect x={196} y={330} width={14} height={290} fill="#6B4A32" />
      <path d="M-4 330 H224 L214 280 H6 Z" fill={C.red} stroke={O} strokeWidth={3} strokeLinejoin="round" />
      <rect x={24} y={350} width={172} height={6} fill="#4a3a2e" />
      {[['#6E96BB', 50], ['#D9A93A', 105], ['#5f9d7a', 160]].map(([c, x], i) => (
        <g key={i} transform={`translate(${x},${362 + Math.sin(f / 18 + i) * 1.5})`}>
          <path d="M0 -8 V6" stroke="#4a3a2e" strokeWidth={3} />
          <Shirt x={0} y={30} k={0.9} c={String(c)} />
        </g>
      ))}
      <Mini x={110} y={540} s={1.5} color="#8f98a0" skin="#8A5530" bob={breathe(f, 1)} />
      <rect x={10} y={520} width={200} height={100} rx={6} fill="#8c6a4f" stroke={O} strokeWidth={3} />
    </g>
  </>
);

export const SC: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const walk = interpolate(t, [29.0, 33.5], [20, 140], clamp);
  const hop = t < 33.5 ? Math.abs(Math.sin(f / 5)) * -4 : 0;
  return (
    <Stage dur={dur}>
      <MarketBg f={f} />
      <Person x={walk} y={520 + hop + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} />
    </Stage>
  );
};

export const SD: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const bulb = sp(lf(38.0));
  return (
    <Stage dur={dur}>
      <MarketBg f={f} />
      <Person x={140} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} sad mouth={mouthOpen('rafi', t)} />
      {t < 38.0 && <Bubble x={190} y={238} text="!" w={54} delay={lf(37.05)} />}
      {t >= 38.0 && t < 40.9 && <Bulb x={210} y={236} k={bulb} />}
      {t >= 41.0 && <Bubble x={190} y={238} text="?" w={54} delay={lf(41.0)} />}
    </Stage>
  );
};

export const SE: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const hx = 520 - sp(lf(43.6), { damping: 18, stiffness: 90, mass: 1 }) * 110;
  const hs = t > 48.8 && t < 55.0;
  return (
    <Stage dur={dur}>
      <MarketBg f={f} />
      <Person x={110} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} sad mouth={mouthOpen('rafi', t)} />
      <Person x={hx} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...HASAN} blink={blinkAt(f + 30)} mouth={mouthOpen('hasan', t)} arm={hs ? 'raise' : 'rest'} hand={hs ? [120 + Math.sin(f / 6) * 6, -150] : undefined} />
    </Stage>
  );
};

// ================= দৃশ্য ৩ : উপলব্ধি =================
export const SF: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const hs = t > 59.9;
  return (
    <Stage dur={dur}>
      <rect width={540} height={960} fill="#D9E3D2" />
      <circle cx={420} cy={190} r={50} fill="#F6E3A1" opacity={0.8} />
      <rect x={60} y={300} width={22} height={310} fill="#6B4A32" />
      <circle cx={71} cy={270} r={90} fill="#7FA886" stroke={O} strokeWidth={3} />
      <rect y={610} width={540} height={350} fill="#B8C79B" />
      <rect y={606} width={540} height={8} fill="#a3b387" />
      <Person x={140} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} mouth={mouthOpen('rafi', t)} />
      <Person x={420} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...HASAN} blink={blinkAt(f + 30)} mouth={mouthOpen('hasan', t)} arm={hs ? 'raise' : 'rest'} hand={hs ? [120 + Math.sin(f / 7) * 5, -150] : undefined} />
      {t > 57.5 && t < 59.9 && <Bubble x={190} y={238} text="?" w={54} delay={lf(57.6)} />}
      {t > 67.3 && (
        <Card x={270} y={230} w={140} h={90} k={sp(lf(67.35))}>
          <rect x={-40} y={-26} width={80} height={46} rx={6} fill="#3b4466" stroke={O} strokeWidth={3} />
          <rect x={-54} y={22} width={108} height={8} rx={4} fill="#8c8c8c" stroke={O} strokeWidth={2.5} />
          <path d="M-22 -4 L-6 8 L22 -16" stroke="#9fe0b0" strokeWidth={5} fill="none" strokeLinecap="round" strokeLinejoin="round" />
        </Card>
      )}
    </Stage>
  );
};

export const SG: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const bars = [0, 1, 2, 3].map((i) => Math.min(1, sp(lf(68.7 + i * 0.35), { damping: 12, stiffness: 120, mass: 0.8 })));
  return (
    <Stage dur={dur}>
      <RoomDay />
      <rect x={215} y={500} width={330} height={14} rx={5} fill="#6B4A32" stroke={O} strokeWidth={3} />
      <rect x={222} y={514} width={14} height={140} fill="#5a3d28" />
      <rect x={510} y={514} width={14} height={140} fill="#5a3d28" />
      <Person x={150} y={560 + breathe(f)} s={0.8} {...RAFI} blink={blinkAt(f)} smile hand={[150, -62]} elbow={[70, -90]} />
      <DeskTop lamp={false} />
      {[0, 1, 2].map((i) => {
        const k = Math.min(1, sp(lf(68.6 + i * 0.5)));
        return <g key={i} opacity={k} transform={`translate(0,${(1 - k) * -30})`}><Box x={330 + i * 62} y={474} k={1.1} /></g>;
      })}
      <g transform="translate(70,128)">
        <rect width={400} height={150} rx={22} fill="#F6EFE8" stroke={O} strokeWidth={3} />
        {bars.map((k, i) => <rect key={i} x={50 + i * 85} y={130 - k * (24 + i * 26)} width={55} height={k * (24 + i * 26)} rx={8} fill={C.teal} />)}
      </g>
    </Stage>
  );
};

export const SH: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  return (
    <Stage dur={dur}>
      <rect width={540} height={960} fill="#E2D6BE" />
      <rect x={30} y={250} width={480} height={360} rx={10} fill="#D8C8A8" stroke={O} strokeWidth={3} />
      <path d="M10 250 H530 L510 190 H30 Z" fill={C.teal} stroke={O} strokeWidth={3} strokeLinejoin="round" />
      <Shirt x={270} y={222} k={1.2} c="#F6EFE8" />
      <rect x={60} y={300} width={190} height={130} rx={8} fill="#9fb8bd" stroke={O} strokeWidth={3} />
      {[['#6E96BB', 100], ['#D9A93A', 155], ['#C8451E', 210]].map(([c, x], i) => <Shirt key={i} x={Number(x)} y={370} k={0.9} c={String(c)} />)}
      <rect y={610} width={540} height={350} fill="#CDBE9E" />
      <rect y={606} width={540} height={8} fill="#bcae8d" />
      <Person x={150} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} smile mouth={mouthOpen('rafi', t)} />
      <Person x={410} y={520 + breathe(f + 15)} s={0.8} pose="stand" flip {...HASAN} blink={blinkAt(f + 30)} smile mouth={mouthOpen('hasan', t)} />
      {[0, 1, 2].map((i) => {
        const k = Math.min(1, sp(lf(71.3 + i * 0.25)));
        return <path key={i} transform={`translate(${105 + i * 42},${228 - Math.sin(f / 8 + i) * 4}) scale(${k})`} opacity={k} d="M0 -16 L5 -5 L17 -4 L8 4 L11 16 L0 9 L-11 16 L-8 4 L-17 -4 L-5 -5 Z" fill="#FFD76A" stroke={O} strokeWidth={2.5} strokeLinejoin="round" />;
      })}
    </Stage>
  );
};

// ================= দৃশ্য ৪ : শেষ শিক্ষা =================
export const SI: React.FC<SP> = ({ t0, dur }) => {
  const { f, lf } = useT(t0);
  const d = Math.min(1, sp(lf(81.9))), m = Math.min(1, sp(lf(82.6))), x = sp(lf(84.9), { damping: 9, stiffness: 220, mass: 0.7 });
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <g transform={`translate(270,200) scale(${d})`} opacity={d}>
        <rect x={-120} y={-44} width={240} height={88} rx={44} fill="#F6EFE8" stroke={O} strokeWidth={3} />
        <circle cx={-30} cy={54} r={9} fill="#F6EFE8" /><circle cx={-48} cy={76} r={5} fill="#F6EFE8" />
        <text y={14} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={44} fill={C.ink}>স্বপ্ন</text>
      </g>
      <Megaphone k={m * (1 + 0.02 * Math.sin(f / 8))} xk={x} />
    </Stage>
  );
};

export const SJ: React.FC<SP> = ({ t0, dur }) => {
  const { f, t } = useT(t0);
  const g = interpolate(t, [86.1, 91.2], [0.05, 1], clamp);
  return (
    <Stage dur={dur}>
      <RoomNight f={f} />
      <DeskNight />
      <Person x={150} y={560 + breathe(f)} s={0.8} {...RAFI} blink={blinkAt(f)} hand={[150, -62]} elbow={[70, -90]} />
      <DeskTop />
      <g transform="translate(470,500)">
        <path d="M-26 0 H26 L20 -40 H-20 Z" fill="#B5543A" stroke={O} strokeWidth={3} strokeLinejoin="round" />
        <g transform={`translate(0,-40) scale(${g})`}>
          <path d="M0 0 Q-4 -40 0 -70" stroke="#5f9d7a" strokeWidth={6} fill="none" strokeLinecap="round" />
          <path d="M0 -40 Q-36 -52 -42 -80 Q-6 -78 0 -40Z" fill="#7fc08f" stroke={O} strokeWidth={2.5} />
          <path d="M0 -56 Q36 -68 42 -96 Q6 -94 0 -56Z" fill="#7fc08f" stroke={O} strokeWidth={2.5} />
        </g>
      </g>
    </Stage>
  );
};

export const SK: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const a = Math.min(1, sp(lf(91.5)));
  const tilt = interpolate(t, [91.5, 92.6, 93.6], [10, -9, 0], clamp) + (t > 93.6 ? Math.sin(f / 10) * 0.4 : 0);
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <g opacity={a} transform={`translate(0,${(1 - a) * 20})`}>
        <path d="M270 330 V560 M200 560 H340" stroke="#6B4A32" strokeWidth={12} strokeLinecap="round" />
        <g transform={`translate(270,330) rotate(${tilt})`}>
          <rect x={-190} y={-6} width={380} height={12} rx={6} fill="#6B4A32" stroke={O} strokeWidth={3} />
          {[-1, 1].map((s) => (
            <g key={s} transform={`translate(${s * 150},0) rotate(${-tilt})`}>
              <path d="M0 6 L-48 100 M0 6 L48 100" stroke={O} strokeWidth={3} />
              <rect x={-84} y={96} width={168} height={72} rx={18} fill={s < 0 ? '#F6EFE8' : C.teal} stroke={O} strokeWidth={3} />
              <text y={142} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={25} fill={s < 0 ? C.ink : '#fff'}>{s < 0 ? 'পরিকল্পনা' : 'বাস্তবায়ন'}</text>
            </g>
          ))}
        </g>
      </g>
    </Stage>
  );
};

export const SL: React.FC<SP> = ({ t0, dur }) => {
  const { lf } = useT(t0);
  const a = sp(lf(95.0)), ar = interpolate(lf(95.4), [0, 10], [0, 1], clamp), b = sp(lf(95.9));
  return (
    <Stage dur={dur} bg={C.cream}>
      <rect width={540} height={960} fill={C.cream} />
      <StepCard y={290} n="১" text="কথা কম" k={a} />
      <g opacity={ar}>
        <path d="M270 380 V470" stroke={C.ink} strokeWidth={8} strokeLinecap="round" />
        <path d="M244 450 L270 480 L296 450" stroke={C.ink} strokeWidth={8} fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </g>
      <StepCard y={580} n="২" text="কাজ বেশি" k={b} />
    </Stage>
  );
};

export const SM: React.FC<SP> = ({ t0, dur }) => {
  const { f, t, lf } = useT(t0);
  const k = Math.min(1, sp(lf(97.3))), v = interpolate(t, [98.6, 99.8], [0, 1], clamp);
  return (
    <Stage dur={dur}>
      <rect width={540} height={960} fill="#E8DBBE" />
      <g transform="translate(405,420)" opacity={0.35}>
        {Array.from({ length: 12 }).map((_, i) => <path key={i} d="M0 -170 L16 -120 H-16 Z" fill="#FFE08A" transform={`rotate(${i * 30 + f * 0.2})`} />)}
      </g>
      <rect y={610} width={540} height={350} fill="#CDBE9E" />
      <rect y={606} width={540} height={8} fill="#bcae8d" />
      <Person x={130} y={520 + breathe(f)} s={0.8} pose="stand" {...RAFI} blink={blinkAt(f)} smile />
      <g transform={`translate(405,560) scale(${k})`} opacity={k}>
        <rect x={-50} y={40} width={100} height={26} rx={6} fill="#6B4A32" stroke={O} strokeWidth={3} />
        <rect x={-10} y={0} width={20} height={44} fill="#E8B84A" stroke={O} strokeWidth={3} />
        <path d="M-60 -110 H60 V-60 Q60 0 0 4 Q-60 0 -60 -60 Z" fill="#F2C94C" stroke={O} strokeWidth={4} strokeLinejoin="round" />
        <path d="M-60 -96 Q-92 -96 -88 -70 Q-84 -46 -56 -42 M60 -96 Q92 -96 88 -70 Q84 -46 56 -42" fill="none" stroke={O} strokeWidth={4} />
        <text y={-52} textAnchor="middle" fontFamily="NSB" fontWeight={800} fontSize={24} fill={C.ink}>সাফল্য</text>
      </g>
      {v > 0 && [0, 1, 2].map((i) => (
        <path key={i} d={`M${335 - i * 26} ${430 - i * 4} Q${318 - i * 26} 470 ${335 - i * 26} ${510 + i * 4}`} stroke={C.red} strokeWidth={6} fill="none" strokeLinecap="round" opacity={Math.min(1, v * 2) * (0.5 + 0.5 * Math.sin(f / 4 - i))} />
      ))}
    </Stage>
  );
};

// List the scenes in time order. s/e are seconds on the final timeline; cuts sit inside voice pauses.
export const SCENES = [
  { s: 0.0, e: 7.4, C: SA }, { s: 7.4, e: 16.9, C: SB1 }, { s: 16.9, e: 29.0, C: SB2 },
  { s: 29.0, e: 36.8, C: SC }, { s: 36.8, e: 43.4, C: SD }, { s: 43.4, e: 55.2, C: SE },
  { s: 55.2, e: 68.4, C: SF }, { s: 68.4, e: 71.1, C: SG }, { s: 71.1, e: 78.2, C: SH },
  { s: 78.2, e: 86.0, C: SI }, { s: 86.0, e: 91.3, C: SJ }, { s: 91.3, e: 94.93, C: SK },
  { s: 94.93, e: 97.0, C: SL }, { s: 97.0, e: TOTAL, C: SM },
];
