// Page/channel name shown as a small watermark pill at the top of every frame.
// Leave empty ('') for NO watermark. Example: export const PAGE_NAME = 'আমার পেজ';
export const PAGE_NAME = '';
